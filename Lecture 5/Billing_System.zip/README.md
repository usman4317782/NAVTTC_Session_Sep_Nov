# SmartBill &mdash; Professional Multi-Page Billing &amp; Receipt Web Application

**SmartBill** is a 100% offline-first, production-grade retail billing and receipt management system built with pure modern web technologies (HTML5, CSS3, Vanilla ES6+ JavaScript, and IndexedDB). It requires **no server, no backend, no npm dependencies, no build tools, and no external CDNs**.

---

## 🌟 Key Features

1. **True Multi-Page Architecture**:
   - `index.html`: Dashboard with real-time financial KPI metrics, interactive native SVG sales trend chart, low-stock warnings, top-selling products, and recent invoices.
   - `billing.html`: Fast Point-of-Sale (POS) & Invoice generator with live subtotal/discount/tax calculations, product barcode/SKU autocomplete, quantity steppers, quick customer creation, payment method selector, balance & change calculator, and direct print preview.
   - `invoices.html`: Invoices history with search by invoice number, customer name or phone, multi-criteria filtering (status, payment method, date range), sorting, pagination, invoice duplication, safe deletion with inventory return option, and receipt printing.
   - `products.html`: Complete product & stock catalog management with category filtering, stock health badges (In Stock, Low Stock, Out of Stock), duplicate SKU validation, profit margin calculation, and soft-delete safeguards.
   - `customers.html`: Customer directory with calculated metrics (total bills, lifetime revenue, outstanding balance, last purchase date), purchase history modal, and customer snapshot protection on past invoices.
   - `settings.html`: Business profile configuration (logo, tax/VAT reg, address), billing preferences (number prefix, starting number, currency symbol, default tax/discount, inventory tracking toggle), theme switcher, full JSON backup export & restore, realistic demo data seeder, and factory reset.

2. **Offline-First & Persistent Browser Storage**:
   - **Primary Engine**: Browser IndexedDB (`SmartBillDB` v1) with 5 dedicated object stores: `invoices`, `products`, `customers`, `settings`, and `inventoryTransactions`.
   - **Preferences**: Small UI states (active theme) stored in `localStorage`.
   - **Data Portability**: Full JSON backup export and restore mechanism with schema validation.

3. **Dual-Format Receipt & Invoice Engine**:
   - **Standard Full Invoice (A4 / Letter)**: Professional layout with store header, logo, customer details, line items table, tax/discount totals, payment breakdown, notes, and signature line.
   - **Compact Thermal POS Receipt (80mm / 58mm)**: POS receipt format with store info, line items, totals, barcode placeholder, and thank-you footer.
   - **Print Dialog**: Native browser print integration (`window.print()`) with dedicated `@media print` rules hiding app navigation, buttons, and backgrounds.

4. **Reliable Financial Calculation Engine**:
   - Explicit floating-point arithmetic rounding (`Math.round((val + Number.EPSILON) * 100) / 100`) preventing decimal precision bugs.
   - Totals recalculated directly from raw data on save.

5. **Design System & Micro-Interactions**:
   - Curated SaaS design tokens (colors, soft shadows, rounded corners, responsive typography).
   - Light and Dark modes with instant toggle and persistent state.
   - Fully responsive layout (Desktop sidebar, Tablet adaptive grid, Mobile drawer navigation with backdrop).
   - Non-blocking toast notifications for user actions.
   - Accessible modal dialogs with keyboard support (Esc to close, Enter to submit).
   - Clear empty states with direct call-to-actions.

---

## 📁 Directory Structure

```text
smartbill/
├── index.html            # Dashboard overview & analytics
├── billing.html          # POS invoice generator & checkout
├── invoices.html         # Invoices history & management
├── products.html         # Product catalog & stock inventory
├── customers.html        # Customer directory & history
├── settings.html         # Business profile, billing setup & backup
│
├── css/
│   ├── style.css         # Design system, layout, cards, forms, tables, modals & toasts
│   ├── responsive.css    # Responsive breakpoints (320px, 480px, 768px, 1024px, 1440px)
│   └── print.css         # Receipt & Invoice print styles (A4 & 80mm POS Thermal)
│
├── js/
│   ├── db.js             # IndexedDB wrapper (SmartBillDB), stores & seed demo data
│   ├── utils.js          # Currency math, date formatting, HTML escaping, modals & toasts
│   ├── app.js            # Shared shell: navigation, mobile drawer, clock & branding sync
│   ├── receipt.js        # Receipt rendering engine (A4 & Thermal 80mm preview & print)
│   ├── dashboard.js      # Dashboard controller & native SVG sales trend chart
│   ├── billing.js        # POS billing controller, live calculations & stock update
│   ├── invoices.js       # Invoices history search, filtering, pagination & duplication
│   ├── products.js       # Product inventory controller & SKU validation
│   ├── customers.js      # Customer directory controller & metrics aggregation
│   └── settings.js       # Settings persistence, theme, JSON backup & restore
│
└── README.md             # Documentation & usage manual
```

---

## 🚀 How to Run the Application

Because SmartBill is 100% vanilla and dependency-free:

1. Double-click or open **`index.html`** in any modern web browser (Google Chrome, Microsoft Edge, Mozilla Firefox, Apple Safari).
2. Alternatively, you can serve it with any local static HTTP server (e.g. Python `python -m http.server 8000` or VS Code Live Server).
3. **No npm install**, **no build step**, and **no internet connection required**!

---

## 🧪 Testing & Verification Guide

### Quick Start with Demo Data:
1. Open `settings.html` (or click "Settings" in the sidebar).
2. Scroll to the **Data Management** card and click **"Load Demo Data"**.
3. The system will seed:
   - 6 products across Electronics, Groceries, Office, and Accessories (with sample low-stock items).
   - 3 realistic customer profiles with contact details.
   - 3 historical invoices with line items, tax, discounts, and varied payment methods.
4. Return to `index.html` to observe the populated KPI metrics, interactive SVG sales chart, and recent invoice records.

### Testing Billing & Invoicing:
1. Go to `billing.html`.
2. Type "mouse" or "keyboard" into the product search bar and click a product to add it.
3. Adjust quantities with the `+` / `-` buttons, test line discounts, and observe the live subtotal and grand total recalculations.
4. Select a customer or use "+ Quick Add" to create a new one on the fly.
5. Enter an amount paid and check the calculated balance due or change returned.
6. Click **"Save & Print Receipt"** to open the print preview modal.
7. Toggle between **Standard (A4)** and **POS Thermal (80mm)** formats, and test the Print button.

### Testing Invoices & Management:
1. Go to `invoices.html` to search, filter by payment status (Paid, Partial, Unpaid), or duplicate an invoice.
2. Go to `products.html` to add new products, test unique SKU validation, and edit prices or stock.
3. Go to `customers.html` to view customer purchase histories and outstanding balances.
4. Export a JSON backup from `settings.html` to verify full offline data backup capability.

---

## 🛡️ License
MIT License &mdash; Free for personal, commercial, and retail use.

/**
 * SmartBill - Settings Controller
 * Business profile configuration, billing preferences, data import/export,
 * demo data loading, and reset management.
 */

document.addEventListener('DOMContentLoaded', async () => {
  await db.initDB();
  await loadAllSettings();
  setupSettingsEventListeners();
});

/**
 * Loads all settings from IndexedDB into form fields
 */
async function loadAllSettings() {
  try {
    const config = await db.getAllSettings();

    // 1. Business Profile
    setVal('businessName', config.businessName || '');
    setVal('ownerName', config.ownerName || '');
    setVal('businessPhone', config.businessPhone || '');
    setVal('businessEmail', config.businessEmail || '');
    setVal('businessAddress', config.businessAddress || '');
    setVal('businessTaxNo', config.businessTaxNo || '');
    setVal('invoiceFooter', config.invoiceFooter || '');

    // Logo preview
    if (config.businessLogo) {
      document.getElementById('logoPreviewContainer').innerHTML = `
        <img src="${config.businessLogo}" alt="Store Logo" style="max-height: 60px; border-radius: 6px; border: 1px solid var(--border-color); object-fit: contain;">
        <button type="button" class="btn btn-secondary btn-sm" id="removeLogoBtn" style="margin-left: 0.5rem;">Remove</button>
      `;
      document.getElementById('removeLogoBtn').addEventListener('click', async () => {
        await db.setSetting('businessLogo', '');
        document.getElementById('logoPreviewContainer').innerHTML = '<span style="font-size:0.8rem; color:var(--text-muted);">No logo uploaded</span>';
        Utils.showToast('Logo removed.', 'info');
      });
    }

    // 2. Billing Defaults
    setVal('invoicePrefix', config.invoicePrefix || 'INV-');
    setVal('startingInvoiceNumber', config.startingInvoiceNumber || 1001);
    setVal('currencySymbol', config.currencySymbol || '$');
    setVal('currencyCode', config.currencyCode || 'USD');
    setVal('decimalPrecision', config.decimalPrecision || 2);
    setVal('defaultTaxRate', config.defaultTaxRate || 8.5);
    setVal('defaultDiscount', config.defaultDiscount || 0);
    setVal('defaultPaymentMethod', config.defaultPaymentMethod || 'Cash');
    setVal('lowStockThreshold', config.lowStockThreshold || 5);

    const invTrack = document.getElementById('inventoryTrackingToggle');
    if (invTrack) invTrack.checked = config.inventoryTracking !== false;

    // 3. Theme selector
    const currentTheme = localStorage.getItem('smartbill_theme') || 'light';
    const themeSelect = document.getElementById('themePreferenceSelect');
    if (themeSelect) themeSelect.value = currentTheme;

  } catch (err) {
    console.error('Error loading settings:', err);
    Utils.showToast('Error loading configuration.', 'error');
  }
}

function setVal(id, val) {
  const el = document.getElementById(id);
  if (el) el.value = val;
}

/**
 * Saves Business Profile
 */
async function saveBusinessProfile(e) {
  e.preventDefault();

  try {
    const businessName = document.getElementById('businessName').value.trim();
    if (!businessName) {
      Utils.showToast('Business name cannot be empty.', 'warning');
      return;
    }

    await db.setSetting('businessName', businessName);
    await db.setSetting('ownerName', document.getElementById('ownerName').value.trim());
    await db.setSetting('businessPhone', document.getElementById('businessPhone').value.trim());
    await db.setSetting('businessEmail', document.getElementById('businessEmail').value.trim());
    await db.setSetting('businessAddress', document.getElementById('businessAddress').value.trim());
    await db.setSetting('businessTaxNo', document.getElementById('businessTaxNo').value.trim());
    await db.setSetting('invoiceFooter', document.getElementById('invoiceFooter').value.trim());

    Utils.showToast('Business profile saved successfully!', 'success');
  } catch (err) {
    console.error('Error saving business profile:', err);
    Utils.showToast('Failed to save profile.', 'error');
  }
}

/**
 * Saves Billing Defaults
 */
async function saveBillingSettings(e) {
  e.preventDefault();

  try {
    const prefix = document.getElementById('invoicePrefix').value.trim() || 'INV-';
    const startNum = parseInt(document.getElementById('startingInvoiceNumber').value, 10) || 1001;
    const curSymbol = document.getElementById('currencySymbol').value.trim() || '$';
    const curCode = document.getElementById('currencyCode').value.trim() || 'USD';
    const dec = parseInt(document.getElementById('decimalPrecision').value, 10);
    const tax = parseFloat(document.getElementById('defaultTaxRate').value) || 0;
    const disc = parseFloat(document.getElementById('defaultDiscount').value) || 0;
    const method = document.getElementById('defaultPaymentMethod').value || 'Cash';
    const lowStock = parseInt(document.getElementById('lowStockThreshold').value, 10) || 5;
    const invTrack = document.getElementById('inventoryTrackingToggle').checked;

    await db.setSetting('invoicePrefix', prefix);
    await db.setSetting('startingInvoiceNumber', startNum);
    await db.setSetting('currencySymbol', curSymbol);
    await db.setSetting('currencyCode', curCode);
    await db.setSetting('decimalPrecision', isNaN(dec) ? 2 : dec);
    await db.setSetting('defaultTaxRate', tax);
    await db.setSetting('defaultDiscount', disc);
    await db.setSetting('defaultPaymentMethod', method);
    await db.setSetting('lowStockThreshold', lowStock);
    await db.setSetting('inventoryTracking', invTrack);

    Utils.showToast('Billing settings updated!', 'success');
  } catch (err) {
    console.error('Error saving billing settings:', err);
    Utils.showToast('Failed to save settings.', 'error');
  }
}

/**
 * Handles Logo Upload
 */
function handleLogoUpload(e) {
  const file = e.target.files[0];
  if (!file) return;

  if (file.size > 1024 * 1024 * 2) {
    Utils.showToast('Logo file size must be less than 2MB.', 'warning');
    return;
  }

  const reader = new FileReader();
  reader.onload = async (event) => {
    const base64Logo = event.target.result;
    await db.setSetting('businessLogo', base64Logo);
    document.getElementById('logoPreviewContainer').innerHTML = `
      <img src="${base64Logo}" alt="Store Logo" style="max-height: 60px; border-radius: 6px; border: 1px solid var(--border-color); object-fit: contain;">
      <button type="button" class="btn btn-secondary btn-sm" id="removeLogoBtn" style="margin-left: 0.5rem;">Remove</button>
    `;
    document.getElementById('removeLogoBtn').addEventListener('click', async () => {
      await db.setSetting('businessLogo', '');
      document.getElementById('logoPreviewContainer').innerHTML = '<span style="font-size:0.8rem; color:var(--text-muted);">No logo uploaded</span>';
      Utils.showToast('Logo removed.', 'info');
    });
    Utils.showToast('Logo uploaded and saved!', 'success');
  };
  reader.readAsDataURL(file);
}

/**
 * Export All Application Data as JSON
 */
async function exportFullBackup() {
  try {
    const backup = await db.exportDatabase();
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(backup, null, 2));
    const downloadAnchor = document.createElement('a');
    const dateStr = Utils.getCurrentDateISO();
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `smartbill-backup-${dateStr}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();

    Utils.showToast('Backup JSON downloaded successfully!', 'success');
  } catch (err) {
    console.error('Export failed:', err);
    Utils.showToast('Backup export failed.', 'error');
  }
}

/**
 * Import JSON Backup File
 */
function handleBackupFileSelect(e) {
  const file = e.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = async (event) => {
    try {
      const parsed = JSON.parse(event.target.result);
      if (!parsed.appName || !parsed.data) {
        throw new Error('Invalid SmartBill backup file structure.');
      }

      const confirmed = confirm(`This will REPLACE current application data with backup from ${parsed.exportedAt || 'file'}.\n\nInvoices: ${(parsed.data.invoices || []).length}\nProducts: ${(parsed.data.products || []).length}\nCustomers: ${(parsed.data.customers || []).length}\n\nProceed?`);
      if (!confirmed) return;

      await db.importDatabase(parsed);
      Utils.showToast('Data restored successfully! Reloading...', 'success');
      setTimeout(() => window.location.reload(), 1200);
    } catch (err) {
      console.error('Import error:', err);
      Utils.showToast(`Import error: ${err.message}`, 'error');
    }
  };
  reader.readAsText(file);
}

/**
 * Load Demo Data
 */
async function handleSeedDemoData() {
  const confirmed = confirm('Load realistic sample products, customers, and invoices for demonstration?');
  if (!confirmed) return;

  try {
    await db.seedDemoData();
    Utils.showToast('Demo data loaded successfully!', 'success');
    setTimeout(() => window.location.reload(), 800);
  } catch (err) {
    console.error('Demo data seed error:', err);
    Utils.showToast('Failed to seed demo data.', 'error');
  }
}

/**
 * Clear All Application Data
 */
async function handleClearAllData() {
  const firstConfirm = confirm('WARNING: Are you sure you want to clear ALL application data (invoices, products, customers, transactions)? This action CANNOT be undone.');
  if (!firstConfirm) return;

  const secondConfirm = prompt('To confirm permanent deletion, type "DELETE" below:');
  if (secondConfirm !== 'DELETE') {
    Utils.showToast('Data reset cancelled.', 'info');
    return;
  }

  try {
    await db.clearAllData();
    Utils.showToast('All data has been reset to factory defaults. Reloading...', 'warning');
    setTimeout(() => window.location.reload(), 1200);
  } catch (err) {
    console.error('Reset error:', err);
    Utils.showToast('Failed to reset data.', 'error');
  }
}

/**
 * Setup All Event Listeners on Settings Page
 */
function setupSettingsEventListeners() {
  // Forms
  document.getElementById('businessProfileForm')?.addEventListener('submit', saveBusinessProfile);
  document.getElementById('billingSettingsForm')?.addEventListener('submit', saveBillingSettings);

  // Logo input
  document.getElementById('logoUploadInput')?.addEventListener('change', handleLogoUpload);

  // Theme selector
  document.getElementById('themePreferenceSelect')?.addEventListener('change', (e) => {
    const val = e.target.value;
    localStorage.setItem('smartbill_theme', val);
    let themeToApply = val;
    if (val === 'system') {
      themeToApply = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    }
    document.documentElement.setAttribute('data-theme', themeToApply);
    Utils.showToast(`Theme updated to ${val}.`, 'info');
  });

  // Data management buttons
  document.getElementById('exportBackupBtn')?.addEventListener('click', exportFullBackup);
  document.getElementById('importBackupBtn')?.addEventListener('click', () => {
    document.getElementById('importBackupFileInput').click();
  });
  document.getElementById('importBackupFileInput')?.addEventListener('change', handleBackupFileSelect);

  document.getElementById('seedDemoDataBtn')?.addEventListener('click', handleSeedDemoData);
  document.getElementById('clearAllDataBtn')?.addEventListener('click', handleClearAllData);
}

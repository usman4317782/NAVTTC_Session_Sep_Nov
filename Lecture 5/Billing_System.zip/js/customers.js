/**
 * SmartBill - Customers Management Controller
 * Customer directory, live invoice metric aggregations, history view & CRUD.
 */

let allCustomers = [];
let allInvoices = [];
let filteredCustomers = [];
let editingCustomerId = null;
let pendingDeleteCustomerId = null;

document.addEventListener('DOMContentLoaded', async () => {
  await db.initDB();
  await loadCustomers();
  setupCustomerEventListeners();
});

async function loadCustomers() {
  try {
    allCustomers = await db.getAll('customers');
    allInvoices = await db.getAll('invoices');
    applyCustomerFilters();
  } catch (err) {
    console.error('Error loading customers:', err);
    Utils.showToast('Failed to load customer records.', 'error');
  }
}

/**
 * Filter customers by search term
 */
function applyCustomerFilters() {
  const search = (document.getElementById('customerSearchInput')?.value || '').toLowerCase().trim();

  filteredCustomers = allCustomers.filter(c => {
    if (!search) return true;
    const name = (c.name || '').toLowerCase();
    const phone = (c.phone || '').toLowerCase();
    const email = (c.email || '').toLowerCase();
    const address = (c.address || '').toLowerCase();
    return name.includes(search) || phone.includes(search) || email.includes(search) || address.includes(search);
  });

  // Sort by name A-Z
  filteredCustomers.sort((a, b) => (a.name || '').localeCompare(b.name || ''));

  renderCustomersTable();
}

/**
 * Renders the customers table with calculated metrics from invoices
 */
async function renderCustomersTable() {
  const tbody = document.getElementById('customersTableBody');
  const countBadge = document.getElementById('customerCountBadge');
  if (!tbody) return;

  const settings = await db.getAllSettings();
  const sym = settings.currencySymbol || '$';
  const dec = parseInt(settings.decimalPrecision || 2, 10);

  if (countBadge) {
    countBadge.textContent = `${filteredCustomers.length} of ${allCustomers.length} registered`;
  }

  if (filteredCustomers.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="7">
          <div class="empty-state">
            <div class="empty-state-icon">
              <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"/></svg>
            </div>
            <div class="empty-state-title">No Customers Found</div>
            <p class="empty-state-desc">Start building your customer base by registering your clients.</p>
            <button class="btn btn-primary btn-sm" onclick="openAddCustomerModal()">+ Add New Customer</button>
          </div>
        </td>
      </tr>
    `;
    return;
  }

  tbody.innerHTML = filteredCustomers.map(c => {
    // Calculate aggregate metrics from invoices
    const customerInvoices = allInvoices.filter(inv => inv.customerId === c.id);
    const invoiceCount = customerInvoices.length;
    let totalSpend = 0;
    let totalOutstanding = 0;
    let lastDate = '-';

    if (invoiceCount > 0) {
      // Sort to get latest
      customerInvoices.sort((a, b) => new Date(b.date) - new Date(a.date));
      lastDate = Utils.formatDate(customerInvoices[0].date);

      customerInvoices.forEach(inv => {
        totalSpend += Number(inv.grandTotal) || 0;
        totalOutstanding += Number(inv.remainingBalance) || 0;
      });
    }

    return `
      <tr>
        <td>
          <div style="font-weight:700; color:var(--text-primary); font-size:0.925rem;">
            ${Utils.escapeHTML(c.name)}
          </div>
          ${c.notes ? `<div style="font-size:0.75rem; color:var(--text-muted);">${Utils.escapeHTML(c.notes)}</div>` : ''}
        </td>
        <td>${Utils.escapeHTML(c.phone || '-')}</td>
        <td>${Utils.escapeHTML(c.email || '-')}</td>
        <td style="font-weight:600; text-align:center;">
          ${invoiceCount > 0 ? `<span class="badge badge-secondary">${invoiceCount}</span>` : '0'}
        </td>
        <td style="font-weight:700;">
          ${Utils.formatCurrency(totalSpend, sym, dec)}
        </td>
        <td>
          ${totalOutstanding > 0 ? `
            <span style="color:var(--danger); font-weight:700;">${Utils.formatCurrency(totalOutstanding, sym, dec)}</span>
          ` : `
            <span style="color:var(--success); font-weight:600;">$0.00</span>
          `}
        </td>
        <td>${lastDate}</td>
        <td>
          <div class="table-actions">
            <button class="btn btn-secondary btn-sm" onclick="viewCustomerHistory('${c.id}')" title="View Invoices History">
              <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" style="width:14px;height:14px;"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
              History
            </button>
            <button class="btn btn-secondary btn-sm" onclick="openEditCustomerModal('${c.id}')" title="Edit Customer">
              <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" style="width:14px;height:14px;"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
              Edit
            </button>
            <button class="btn btn-icon btn-sm" style="color:var(--danger);" onclick="promptDeleteCustomer('${c.id}')" title="Delete Customer">
              <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" style="width:14px;height:14px;"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
            </button>
          </div>
        </td>
      </tr>
    `;
  }).join('');
}

/**
 * Open Add Customer Modal
 */
function openAddCustomerModal() {
  editingCustomerId = null;
  document.getElementById('customerModalTitle').textContent = 'Add New Customer';
  document.getElementById('customerForm').reset();
  Utils.openModal('customerModal');
}

/**
 * Open Edit Customer Modal
 */
function openEditCustomerModal(id) {
  const cust = allCustomers.find(c => c.id === id);
  if (!cust) return;

  editingCustomerId = id;
  document.getElementById('customerModalTitle').textContent = 'Edit Customer';

  document.getElementById('custModalName').value = cust.name || '';
  document.getElementById('custModalPhone').value = cust.phone || '';
  document.getElementById('custModalEmail').value = cust.email || '';
  document.getElementById('custModalAddress').value = cust.address || '';
  document.getElementById('custModalNotes').value = cust.notes || '';

  Utils.openModal('customerModal');
}

/**
 * View Customer History Modal
 */
async function viewCustomerHistory(id) {
  const cust = allCustomers.find(c => c.id === id);
  if (!cust) return;

  const settings = await db.getAllSettings();
  const sym = settings.currencySymbol || '$';
  const dec = parseInt(settings.decimalPrecision || 2, 10);

  const customerInvoices = allInvoices.filter(inv => inv.customerId === id);
  customerInvoices.sort((a, b) => new Date(b.date) - new Date(a.date));

  document.getElementById('historyCustomerName').textContent = cust.name;
  const listContainer = document.getElementById('customerHistoryInvoicesList');

  if (customerInvoices.length === 0) {
    listContainer.innerHTML = `
      <div class="empty-state" style="padding: 2rem 1rem;">
        <p class="empty-state-desc">No invoices recorded for this customer yet.</p>
        <a href="billing.html" class="btn btn-primary btn-sm">Create New Bill</a>
      </div>
    `;
  } else {
    listContainer.innerHTML = `
      <table class="table" style="font-size:0.85rem;">
        <thead>
          <tr>
            <th>Invoice #</th>
            <th>Date</th>
            <th>Amount</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          ${customerInvoices.map(inv => `
            <tr>
              <td><strong>${Utils.escapeHTML(inv.invoiceNumber)}</strong></td>
              <td>${Utils.formatDate(inv.date)}</td>
              <td><strong>${Utils.formatCurrency(inv.grandTotal, sym, dec)}</strong></td>
              <td>
                <span class="badge ${inv.paymentStatus === 'Paid' ? 'badge-paid' : 'badge-unpaid'}">
                  ${inv.paymentStatus}
                </span>
              </td>
              <td>
                <button class="btn btn-secondary btn-sm" onclick="ReceiptManager.showPreview('${inv.id}')">
                  View Receipt
                </button>
              </td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    `;
  }

  Utils.openModal('customerHistoryModal');
}

/**
 * Save Customer Form
 */
async function saveCustomerForm(e) {
  e.preventDefault();

  const name = document.getElementById('custModalName').value.trim();
  const phone = document.getElementById('custModalPhone').value.trim();
  const email = document.getElementById('custModalEmail').value.trim();
  const address = document.getElementById('custModalAddress').value.trim();
  const notes = document.getElementById('custModalNotes').value.trim();

  if (!name) {
    Utils.showToast('Customer name is required.', 'warning');
    return;
  }

  const customerData = {
    id: editingCustomerId || Utils.generateId('cust'),
    name,
    phone: phone || '-',
    email: email || '-',
    address: address || '-',
    notes,
    updatedAt: new Date().toISOString()
  };

  if (!editingCustomerId) {
    customerData.createdAt = new Date().toISOString();
  }

  try {
    await db.put('customers', customerData);
    Utils.closeModal('customerModal');
    Utils.showToast(editingCustomerId ? 'Customer updated.' : 'Customer registered successfully!', 'success');
    await loadCustomers();
  } catch (err) {
    console.error('Error saving customer:', err);
    Utils.showToast('Failed to save customer.', 'error');
  }
}

/**
 * Prompt to delete customer
 */
function promptDeleteCustomer(id) {
  const cust = allCustomers.find(c => c.id === id);
  if (!cust) return;

  pendingDeleteCustomerId = id;
  const nameEl = document.getElementById('deleteCustName');
  if (nameEl) nameEl.textContent = cust.name;

  Utils.openModal('deleteCustomerModal');
}

async function executeDeleteCustomer() {
  if (!pendingDeleteCustomerId) return;

  try {
    await db.deleteItem('customers', pendingDeleteCustomerId);
    Utils.closeModal('deleteCustomerModal');
    Utils.showToast('Customer removed. Past invoice records retain snapshot history.', 'success');
    pendingDeleteCustomerId = null;
    await loadCustomers();
  } catch (err) {
    console.error('Error deleting customer:', err);
    Utils.showToast('Failed to delete customer.', 'error');
  }
}

/**
 * Event Listeners
 */
function setupCustomerEventListeners() {
  const addBtn = document.getElementById('addNewCustomerBtn');
  if (addBtn) addBtn.addEventListener('click', openAddCustomerModal);

  const form = document.getElementById('customerForm');
  if (form) form.addEventListener('submit', saveCustomerForm);

  const searchInput = document.getElementById('customerSearchInput');
  if (searchInput) searchInput.addEventListener('input', Utils.debounce(applyCustomerFilters, 200));

  const confirmDeleteBtn = document.getElementById('confirmDeleteCustBtn');
  if (confirmDeleteBtn) confirmDeleteBtn.addEventListener('click', executeDeleteCustomer);
}

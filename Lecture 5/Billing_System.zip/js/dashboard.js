/**
 * SmartBill - Dashboard Controller
 * Aggregates KPI statistics, renders native SVG sales chart, recent invoices,
 * top-selling products, and low-stock alerts.
 */

document.addEventListener('DOMContentLoaded', async () => {
  await db.initDB();
  await loadDashboard();
});

async function loadDashboard() {
  try {
    const settings = await db.getAllSettings();
    const sym = settings.currencySymbol || '$';
    const dec = parseInt(settings.decimalPrecision || 2, 10);

    const invoices = await db.getAll('invoices');
    const products = await db.getAll('products');
    const customers = await db.getAll('customers');

    // 1. Calculate KPI Metrics
    const todayISO = Utils.getCurrentDateISO();
    let totalSales = 0;
    let todaySales = 0;
    let todayInvoiceCount = 0;

    invoices.forEach(inv => {
      const amount = Number(inv.grandTotal) || 0;
      totalSales += amount;

      if (inv.date === todayISO) {
        todaySales += amount;
        todayInvoiceCount += 1;
      }
    });

    // Populate KPI Cards
    document.getElementById('kpiTotalSales').textContent = Utils.formatCurrency(totalSales, sym, dec);
    document.getElementById('kpiTotalInvoices').textContent = invoices.length.toLocaleString();
    document.getElementById('kpiTotalCustomers').textContent = customers.length.toLocaleString();
    document.getElementById('kpiTotalProducts').textContent = products.length.toLocaleString();
    document.getElementById('kpiTodaySales').textContent = Utils.formatCurrency(todaySales, sym, dec);
    document.getElementById('kpiTodayCount').textContent = todayInvoiceCount.toLocaleString();

    // 2. Render Native SVG Sales Trend Chart (Last 7 Days)
    renderSalesChart(invoices, sym, dec);

    // 3. Render Recent Invoices Table
    renderRecentInvoices(invoices, sym, dec);

    // 4. Render Top Selling Products
    renderTopProducts(invoices, products, sym, dec);

    // 5. Render Low-Stock Products Alert
    renderLowStockAlerts(products);

  } catch (err) {
    console.error('Error loading dashboard data:', err);
    Utils.showToast('Error loading dashboard data', 'error');
  }
}

/**
 * Renders an interactive, responsive native SVG Bar Chart of sales over the past 7 days.
 */
function renderSalesChart(invoices, sym, dec) {
  const chartEl = document.getElementById('salesChartContainer');
  if (!chartEl) return;

  // Generate date labels for past 7 days
  const days = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    days.push({
      dateISO: d.toISOString().split('T')[0],
      dayName: d.toLocaleDateString('en-US', { weekday: 'short' }),
      dateLabel: d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      total: 0
    });
  }

  // Aggregate invoice totals by day
  invoices.forEach(inv => {
    const dayObj = days.find(d => d.dateISO === inv.date);
    if (dayObj) {
      dayObj.total += Number(inv.grandTotal) || 0;
    }
  });

  const maxVal = Math.max(...days.map(d => d.total), 50); // Minimum scale 50

  // SVG dimensions
  const svgWidth = 700;
  const svgHeight = 220;
  const paddingLeft = 60;
  const paddingRight = 20;
  const paddingTop = 20;
  const paddingBottom = 35;

  const chartWidth = svgWidth - paddingLeft - paddingRight;
  const chartHeight = svgHeight - paddingTop - paddingBottom;
  const barWidth = Math.min(48, (chartWidth / days.length) * 0.55);
  const step = chartWidth / days.length;

  // Grid lines
  const gridLinesCount = 4;
  let gridSvg = '';
  for (let g = 0; g <= gridLinesCount; g++) {
    const yVal = (maxVal / gridLinesCount) * g;
    const yPos = paddingTop + chartHeight - (g / gridLinesCount) * chartHeight;
    gridSvg += `
      <line x1="${paddingLeft}" y1="${yPos}" x2="${svgWidth - paddingRight}" y2="${yPos}" class="chart-grid-line" />
      <text x="${paddingLeft - 10}" y="${yPos + 4}" text-anchor="end" class="chart-axis-text">
        ${sym}${Math.round(yVal)}
      </text>
    `;
  }

  // Bars and labels
  let barsSvg = '';
  days.forEach((day, idx) => {
    const barHeight = (day.total / maxVal) * chartHeight;
    const xPos = paddingLeft + (idx * step) + (step - barWidth) / 2;
    const yPos = paddingTop + chartHeight - barHeight;

    barsSvg += `
      <g class="chart-bar-group" data-total="${day.total}" data-date="${day.dateLabel}">
        <rect x="${xPos}" y="${yPos}" width="${barWidth}" height="${Math.max(barHeight, 2)}" class="chart-bar" />
        <text x="${xPos + barWidth / 2}" y="${svgHeight - 12}" text-anchor="middle" class="chart-axis-text">
          ${day.dayName}
        </text>
      </g>
    `;
  });

  chartEl.innerHTML = `
    <svg viewBox="0 0 ${svgWidth} ${svgHeight}" class="chart-svg" preserveAspectRatio="none">
      ${gridSvg}
      ${barsSvg}
    </svg>
    <div id="chartTooltip" class="chart-tooltip"></div>
  `;

  // Add hover tooltips
  const tooltip = document.getElementById('chartTooltip');
  const barGroups = chartEl.querySelectorAll('.chart-bar-group');

  barGroups.forEach(group => {
    group.addEventListener('mouseenter', (e) => {
      const rect = e.currentTarget.querySelector('rect').getBoundingClientRect();
      const parentRect = chartEl.getBoundingClientRect();
      const total = Number(e.currentTarget.dataset.total);
      const date = e.currentTarget.dataset.date;

      tooltip.textContent = `${date}: ${Utils.formatCurrency(total, sym, dec)}`;
      tooltip.style.left = `${(rect.left + rect.width / 2) - parentRect.left}px`;
      tooltip.style.top = `${rect.top - parentRect.top}px`;
      tooltip.style.opacity = '1';
    });

    group.addEventListener('mouseleave', () => {
      tooltip.style.opacity = '0';
    });
  });
}

/**
 * Renders the Recent Invoices table (Last 5 invoices sorted by date/time descending)
 */
function renderRecentInvoices(invoices, sym, dec) {
  const container = document.getElementById('recentInvoicesTableBody');
  if (!container) return;

  if (invoices.length === 0) {
    container.innerHTML = `
      <tr>
        <td colspan="6">
          <div class="empty-state" style="padding: 2rem 1rem;">
            <div class="empty-state-icon" style="width:48px;height:48px;margin-bottom:0.75rem;">
              <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
            </div>
            <div class="empty-state-title" style="font-size:1rem;">No Invoices Yet</div>
            <p class="empty-state-desc" style="font-size:0.8rem; margin-bottom:1rem;">Start ringing up sales to see your transactions here.</p>
            <a href="billing.html" class="btn btn-primary btn-sm">Create New Invoice</a>
          </div>
        </td>
      </tr>
    `;
    return;
  }

  // Sort descending by date and createdAt
  const sorted = [...invoices].sort((a, b) => new Date(b.createdAt || b.date) - new Date(a.createdAt || a.date)).slice(0, 6);

  container.innerHTML = sorted.map(inv => {
    const cust = inv.customerSnapshot || {};
    const badgeClass = inv.paymentStatus === 'Paid' ? 'badge-paid' : (inv.paymentStatus === 'Partial' ? 'badge-partial' : 'badge-unpaid');

    return `
      <tr>
        <td>
          <a href="#" onclick="ReceiptManager.showPreview('${inv.id}'); return false;" style="font-weight:700; color:var(--primary);">
            ${Utils.escapeHTML(inv.invoiceNumber)}
          </a>
        </td>
        <td>
          <div style="font-weight:600;">${Utils.escapeHTML(cust.name || 'Walk-in')}</div>
          <div style="font-size:0.75rem; color:var(--text-muted);">${Utils.escapeHTML(cust.phone || '')}</div>
        </td>
        <td>${Utils.formatDate(inv.date)}</td>
        <td style="font-weight:700;">${Utils.formatCurrency(inv.grandTotal, sym, dec)}</td>
        <td><span class="badge ${badgeClass}"><span class="badge-dot"></span>${inv.paymentStatus || 'Paid'}</span></td>
        <td>
          <div class="table-actions">
            <button class="btn btn-secondary btn-sm" onclick="ReceiptManager.showPreview('${inv.id}')" title="View & Print Receipt">
              <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" style="width:14px;height:14px;"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
              View
            </button>
          </div>
        </td>
      </tr>
    `;
  }).join('');
}

/**
 * Calculates and renders top-selling products by units sold
 */
function renderTopProducts(invoices, products, sym, dec) {
  const container = document.getElementById('topProductsList');
  if (!container) return;

  const productSales = {};

  invoices.forEach(inv => {
    (inv.items || []).forEach(item => {
      const pId = item.productId || item.sku || item.name;
      if (!productSales[pId]) {
        productSales[pId] = {
          name: item.name,
          sku: item.sku,
          units: 0,
          revenue: 0
        };
      }
      productSales[pId].units += Number(item.quantity) || 0;
      productSales[pId].revenue += Number(item.lineTotal) || 0;
    });
  });

  const topList = Object.values(productSales)
    .sort((a, b) => b.units - a.units)
    .slice(0, 5);

  if (topList.length === 0) {
    container.innerHTML = `
      <div class="empty-state" style="padding: 1.5rem;">
        <p class="empty-state-desc" style="margin-bottom:0;">No sales data available yet.</p>
      </div>
    `;
    return;
  }

  container.innerHTML = topList.map((item, idx) => `
    <div style="display:flex; align-items:center; justify-content:space-between; padding:0.75rem 0; border-bottom:1px solid var(--border-color-subtle);">
      <div style="display:flex; align-items:center; gap:0.75rem;">
        <span style="width:24px; height:24px; border-radius:50%; background:var(--bg-surface-secondary); display:flex; align-items:center; justify-content:center; font-size:0.75rem; font-weight:700; color:var(--text-secondary);">
          ${idx + 1}
        </span>
        <div>
          <div style="font-weight:600; font-size:0.875rem;">${Utils.escapeHTML(item.name)}</div>
          <div style="font-size:0.75rem; color:var(--text-muted);">${item.sku ? `SKU: ${Utils.escapeHTML(item.sku)} • ` : ''}${item.units} sold</div>
        </div>
      </div>
      <div style="font-weight:700; color:var(--text-primary); font-size:0.875rem;">
        ${Utils.formatCurrency(item.revenue, sym, dec)}
      </div>
    </div>
  `).join('');
}

/**
 * Identifies and alerts about low-stock products
 */
function renderLowStockAlerts(products) {
  const container = document.getElementById('lowStockAlertsList');
  if (!container) return;

  const lowStock = products.filter(p => {
    if (p.isActive === false) return false;
    const qty = Number(p.stockQuantity) || 0;
    const threshold = Number(p.lowStockThreshold) || 5;
    return qty <= threshold;
  });

  if (lowStock.length === 0) {
    container.innerHTML = `
      <div style="display:flex; align-items:center; gap:0.6rem; padding:0.85rem; background-color:var(--success-bg); border:1px solid var(--success-border); border-radius:var(--radius-md); color:var(--success-text); font-size:0.85rem; font-weight:500;">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" style="width:18px;height:18px;flex-shrink:0;"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
        All inventory levels are healthy! No low-stock items.
      </div>
    `;
    return;
  }

  container.innerHTML = lowStock.map(p => `
    <div style="display:flex; align-items:center; justify-content:space-between; padding:0.75rem; background:var(--warning-bg); border:1px solid var(--warning-border); border-radius:var(--radius-md); margin-bottom:0.5rem;">
      <div>
        <div style="font-weight:700; font-size:0.85rem; color:var(--warning-text);">${Utils.escapeHTML(p.name)}</div>
        <div style="font-size:0.75rem; color:var(--text-secondary);">SKU: ${Utils.escapeHTML(p.sku || '-')} • Min: ${p.lowStockThreshold}</div>
      </div>
      <div style="text-align:right;">
        <span class="badge ${p.stockQuantity <= 0 ? 'badge-danger' : 'badge-warning'}">
          ${p.stockQuantity <= 0 ? 'Out of Stock' : `${p.stockQuantity} remaining`}
        </span>
      </div>
    </div>
  `).join('');
}

/**
 * SmartBill - Utility Functions
 * Safe arithmetic, currency & date formatters, HTML escaping, modals & toasts.
 */

const Utils = {
  /**
   * Round to 2 decimal places to avoid floating point precision errors.
   */
  roundCurrency(amount) {
    const num = Number(amount) || 0;
    return Math.round((num + Number.EPSILON) * 100) / 100;
  },

  /**
   * Formats a numeric value as a currency string.
   */
  formatCurrency(amount, symbol = '$', decimals = 2) {
    const num = Number(amount) || 0;
    const parts = num.toFixed(decimals).split('.');
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return `${symbol}${parts.join('.')}`;
  },

  /**
   * Formats an ISO date string or Date object to readable date: "MMM DD, YYYY".
   */
  formatDate(dateInput) {
    if (!dateInput) return '-';
    try {
      const date = new Date(dateInput);
      if (isNaN(date.getTime())) return String(dateInput);
      return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      });
    } catch (e) {
      return String(dateInput);
    }
  },

  /**
   * Formats time to "hh:mm AM/PM".
   */
  formatTime(dateInput) {
    if (!dateInput) return '';
    try {
      const date = new Date(dateInput);
      if (isNaN(date.getTime())) return String(dateInput);
      return date.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: true
      });
    } catch (e) {
      return '';
    }
  },

  /**
   * Current ISO Date (YYYY-MM-DD)
   */
  getCurrentDateISO() {
    return new Date().toISOString().split('T')[0];
  },

  /**
   * Current readable time string (e.g. "10:30 AM")
   */
  getCurrentTimeStr() {
    return new Date().toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });
  },

  /**
   * Escapes HTML characters to prevent XSS injection.
   */
  escapeHTML(str) {
    if (str === null || str === undefined) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  },

  /**
   * Generates a unique alphanumeric ID with an optional prefix.
   */
  generateId(prefix = 'id') {
    return `${prefix}_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
  },

  /**
   * Debounce execution of a function.
   */
  debounce(func, wait = 250) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  },

  /**
   * Toast notification system.
   * Types: 'success', 'error', 'warning', 'info'
   */
  showToast(message, type = 'info', duration = 3500) {
    let container = document.querySelector('.toast-container');
    if (!container) {
      container = document.createElement('div');
      container.className = 'toast-container';
      document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;

    let iconSvg = '';
    if (type === 'success') {
      iconSvg = '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>';
    } else if (type === 'error') {
      iconSvg = '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>';
    } else if (type === 'warning') {
      iconSvg = '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path></svg>';
    } else {
      iconSvg = '<svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>';
    }

    toast.innerHTML = `
      <div class="toast-icon">${iconSvg}</div>
      <div class="toast-content">${this.escapeHTML(message)}</div>
      <button class="toast-close" aria-label="Close">&times;</button>
    `;

    const closeBtn = toast.querySelector('.toast-close');
    const dismiss = () => {
      toast.classList.remove('show');
      setTimeout(() => {
        if (toast.parentElement) toast.parentElement.removeChild(toast);
      }, 300);
    };

    closeBtn.addEventListener('click', dismiss);
    container.appendChild(toast);

    // Trigger animation
    requestAnimationFrame(() => {
      toast.classList.add('show');
    });

    if (duration > 0) {
      setTimeout(dismiss, duration);
    }
  },

  /**
   * Modal dialog open helper
   */
  openModal(modalId) {
    const backdrop = document.getElementById(modalId);
    if (!backdrop) return;
    backdrop.classList.add('active');
    document.body.style.overflow = 'hidden';

    // Focus first input if available
    const firstInput = backdrop.querySelector('input, select, textarea, button:not(.modal-close)');
    if (firstInput) {
      setTimeout(() => firstInput.focus(), 50);
    }
  },

  /**
   * Modal dialog close helper
   */
  closeModal(modalId) {
    const backdrop = document.getElementById(modalId);
    if (!backdrop) return;
    backdrop.classList.remove('active');
    document.body.style.overflow = '';
  },

  /**
   * Setup global modal dismiss listeners (clicks on backdrop, ESC key)
   */
  initModalListeners() {
    document.addEventListener('click', (e) => {
      if (e.target.classList.contains('modal-backdrop')) {
        this.closeModal(e.target.id);
      }
      if (e.target.closest('.modal-close') || e.target.closest('[data-modal-close]')) {
        const backdrop = e.target.closest('.modal-backdrop');
        if (backdrop) this.closeModal(backdrop.id);
      }
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        const activeModal = document.querySelector('.modal-backdrop.active');
        if (activeModal) this.closeModal(activeModal.id);
      }
    });
  }
};

// Auto-initialize global modal handlers on script load
Utils.initModalListeners();

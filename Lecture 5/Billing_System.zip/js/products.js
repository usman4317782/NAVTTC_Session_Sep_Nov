/**
 * SmartBill - Products & Inventory Controller
 * Catalog management, SKU validation, stock tracking, category filtering & CRUD.
 */

let allProducts = [];
let filteredProducts = [];
let editingProductId = null;
let pendingDeleteProductId = null;

document.addEventListener('DOMContentLoaded', async () => {
  await db.initDB();
  await loadProducts();
  setupProductEventListeners();
});

async function loadProducts() {
  try {
    allProducts = await db.getAll('products');
    populateCategoryFilter();
    applyProductFilters();
  } catch (err) {
    console.error('Error loading products:', err);
    Utils.showToast('Failed to load products.', 'error');
  }
}

/**
 * Extracts distinct categories from existing products to populate filter dropdown
 */
function populateCategoryFilter() {
  const categoryFilter = document.getElementById('categoryFilter');
  if (!categoryFilter) return;

  const currentVal = categoryFilter.value;
  const categories = Array.from(new Set(allProducts.map(p => p.category).filter(Boolean))).sort();

  categoryFilter.innerHTML = `
    <option value="all">All Categories</option>
    ${categories.map(c => `<option value="${Utils.escapeHTML(c)}">${Utils.escapeHTML(c)}</option>`).join('')}
  `;

  if (categories.includes(currentVal)) {
    categoryFilter.value = currentVal;
  }
}

/**
 * Filter & Sort Logic
 */
function applyProductFilters() {
  const search = (document.getElementById('productSearchInput')?.value || '').toLowerCase().trim();
  const category = document.getElementById('categoryFilter')?.value || 'all';
  const stockFilter = document.getElementById('stockStatusFilter')?.value || 'all';
  const sort = document.getElementById('productSortFilter')?.value || 'name_asc';

  filteredProducts = allProducts.filter(p => {
    // Search query
    if (search) {
      const name = (p.name || '').toLowerCase();
      const sku = (p.sku || '').toLowerCase();
      const desc = (p.description || '').toLowerCase();
      if (!name.includes(search) && !sku.includes(search) && !desc.includes(search)) {
        return false;
      }
    }

    // Category filter
    if (category !== 'all' && p.category !== category) {
      return false;
    }

    // Stock status filter
    const stock = Number(p.stockQuantity) || 0;
    const threshold = Number(p.lowStockThreshold) || 5;

    if (stockFilter === 'in_stock' && stock <= threshold) return false;
    if (stockFilter === 'low_stock' && (stock <= 0 || stock > threshold)) return false;
    if (stockFilter === 'out_of_stock' && stock > 0) return false;

    return true;
  });

  // Sorting
  if (sort === 'name_asc') {
    filteredProducts.sort((a, b) => (a.name || '').localeCompare(b.name || ''));
  } else if (sort === 'name_desc') {
    filteredProducts.sort((a, b) => (b.name || '').localeCompare(a.name || ''));
  } else if (sort === 'price_high') {
    filteredProducts.sort((a, b) => (Number(b.sellingPrice) || 0) - (Number(a.sellingPrice) || 0));
  } else if (sort === 'price_low') {
    filteredProducts.sort((a, b) => (Number(a.sellingPrice) || 0) - (Number(b.sellingPrice) || 0));
  } else if (sort === 'stock_low') {
    filteredProducts.sort((a, b) => (Number(a.stockQuantity) || 0) - (Number(b.stockQuantity) || 0));
  }

  renderProductsTable();
}

/**
 * Render Products Table
 */
async function renderProductsTable() {
  const tbody = document.getElementById('productsTableBody');
  const countBadge = document.getElementById('productCountBadge');
  if (!tbody) return;

  const settings = await db.getAllSettings();
  const sym = settings.currencySymbol || '$';
  const dec = parseInt(settings.decimalPrecision || 2, 10);

  if (countBadge) {
    countBadge.textContent = `${filteredProducts.length} of ${allProducts.length} items`;
  }

  if (filteredProducts.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="7">
          <div class="empty-state">
            <div class="empty-state-icon">
              <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>
            </div>
            <div class="empty-state-title">No Products Found</div>
            <p class="empty-state-desc">Try adjusting your filters or click below to add a new inventory product.</p>
            <button class="btn btn-primary btn-sm" onclick="openAddProductModal()">+ Add New Product</button>
          </div>
        </td>
      </tr>
    `;
    return;
  }

  tbody.innerHTML = filteredProducts.map(p => {
    const stock = Number(p.stockQuantity) || 0;
    const threshold = Number(p.lowStockThreshold) || 5;

    let badgeHtml = '';
    if (stock <= 0) {
      badgeHtml = '<span class="badge badge-danger"><span class="badge-dot"></span>Out of Stock</span>';
    } else if (stock <= threshold) {
      badgeHtml = `<span class="badge badge-warning"><span class="badge-dot"></span>Low (${stock})</span>`;
    } else {
      badgeHtml = `<span class="badge badge-success"><span class="badge-dot"></span>In Stock (${stock})</span>`;
    }

    const buy = Number(p.purchasePrice) || 0;
    const sell = Number(p.sellingPrice) || 0;
    const margin = sell > 0 ? (((sell - buy) / sell) * 100).toFixed(0) : 0;

    return `
      <tr>
        <td>
          <div style="font-weight:700; color:var(--text-primary); font-size:0.925rem;">
            ${Utils.escapeHTML(p.name)}
          </div>
          ${p.description ? `<div style="font-size:0.775rem; color:var(--text-muted); max-width:300px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${Utils.escapeHTML(p.description)}</div>` : ''}
        </td>
        <td>
          <span style="font-family:var(--font-mono); font-size:0.8rem; background:var(--bg-surface-secondary); padding:2px 6px; border-radius:4px; border:1px solid var(--border-color);">
            ${Utils.escapeHTML(p.sku || '-')}
          </span>
        </td>
        <td>
          <span class="badge badge-secondary">${Utils.escapeHTML(p.category || 'General')}</span>
        </td>
        <td style="font-weight:600;">
          ${Utils.formatCurrency(p.sellingPrice, sym, dec)}
          ${buy > 0 ? `<div style="font-size:0.725rem; color:var(--text-muted);">Cost: ${Utils.formatCurrency(buy, sym, dec)} (${margin}% profit)</div>` : ''}
        </td>
        <td>
          ${badgeHtml}
          <div style="font-size:0.725rem; color:var(--text-muted); margin-top:2px;">Threshold: ${threshold}</div>
        </td>
        <td>
          <span class="badge ${p.isActive !== false ? 'badge-success' : 'badge-secondary'}">
            ${p.isActive !== false ? 'Active' : 'Inactive'}
          </span>
        </td>
        <td>
          <div class="table-actions">
            <button class="btn btn-secondary btn-sm" onclick="openEditProductModal('${p.id}')" title="Edit Product">
              <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" style="width:14px;height:14px;"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>
              Edit
            </button>
            <button class="btn btn-icon btn-sm" style="color:var(--danger);" onclick="promptDeleteProduct('${p.id}')" title="Delete Product">
              <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" style="width:14px;height:14px;"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
            </button>
          </div>
        </td>
      </tr>
    `;
  }).join('');
}

/**
 * Open Modal for Adding New Product
 */
function openAddProductModal() {
  editingProductId = null;
  document.getElementById('productModalTitle').textContent = 'Add New Product';
  document.getElementById('productForm').reset();
  document.getElementById('productIsActive').checked = true;
  Utils.openModal('productModal');
}

/**
 * Open Modal for Editing Existing Product
 */
function openEditProductModal(id) {
  const prod = allProducts.find(p => p.id === id);
  if (!prod) return;

  editingProductId = id;
  document.getElementById('productModalTitle').textContent = 'Edit Product';

  document.getElementById('prodName').value = prod.name || '';
  document.getElementById('prodSku').value = prod.sku || '';
  document.getElementById('prodCategory').value = prod.category || '';
  document.getElementById('prodPurchasePrice').value = prod.purchasePrice || 0;
  document.getElementById('prodSellingPrice').value = prod.sellingPrice || 0;
  document.getElementById('prodStockQty').value = prod.stockQuantity || 0;
  document.getElementById('prodLowStock').value = prod.lowStockThreshold || 5;
  document.getElementById('prodDescription').value = prod.description || '';
  document.getElementById('productIsActive').checked = prod.isActive !== false;

  Utils.openModal('productModal');
}

/**
 * Save Product (Create or Update) with Duplicate SKU Validation
 */
async function saveProductForm(e) {
  e.preventDefault();

  const name = document.getElementById('prodName').value.trim();
  const sku = document.getElementById('prodSku').value.trim().toUpperCase();
  const category = document.getElementById('prodCategory').value.trim();
  const purchasePrice = parseFloat(document.getElementById('prodPurchasePrice').value) || 0;
  const sellingPrice = parseFloat(document.getElementById('prodSellingPrice').value) || 0;
  const stockQuantity = parseInt(document.getElementById('prodStockQty').value, 10) || 0;
  const lowStockThreshold = parseInt(document.getElementById('prodLowStock').value, 10) || 5;
  const description = document.getElementById('prodDescription').value.trim();
  const isActive = document.getElementById('productIsActive').checked;

  if (!name) {
    Utils.showToast('Product name is required.', 'warning');
    return;
  }

  if (purchasePrice < 0 || sellingPrice < 0) {
    Utils.showToast('Prices cannot be negative.', 'warning');
    return;
  }

  if (stockQuantity < 0) {
    Utils.showToast('Stock quantity cannot be negative.', 'warning');
    return;
  }

  // Check duplicate SKU if SKU is provided
  if (sku) {
    const existingWithSku = allProducts.find(p => p.sku === sku && p.id !== editingProductId);
    if (existingWithSku) {
      Utils.showToast(`SKU "${sku}" is already assigned to "${existingWithSku.name}".`, 'error');
      return;
    }
  }

  const productData = {
    id: editingProductId || Utils.generateId('prod'),
    name,
    sku: sku || Utils.generateId('SKU'),
    category: category || 'General',
    purchasePrice: Utils.roundCurrency(purchasePrice),
    sellingPrice: Utils.roundCurrency(sellingPrice),
    stockQuantity,
    lowStockThreshold,
    description,
    isActive,
    updatedAt: new Date().toISOString()
  };

  if (!editingProductId) {
    productData.createdAt = new Date().toISOString();
  }

  try {
    await db.put('products', productData);
    Utils.closeModal('productModal');
    Utils.showToast(editingProductId ? 'Product updated successfully!' : 'Product created successfully!', 'success');
    await loadProducts();
  } catch (err) {
    console.error('Error saving product:', err);
    Utils.showToast('Failed to save product.', 'error');
  }
}

/**
 * Delete product with safety verification
 */
function promptDeleteProduct(id) {
  const prod = allProducts.find(p => p.id === id);
  if (!prod) return;

  pendingDeleteProductId = id;
  const nameEl = document.getElementById('deleteProductName');
  if (nameEl) nameEl.textContent = prod.name;

  Utils.openModal('deleteProductModal');
}

async function executeDeleteProduct() {
  if (!pendingDeleteProductId) return;

  try {
    // Check historical invoices
    const allInvoices = await db.getAll('invoices');
    const wasUsed = allInvoices.some(inv => (inv.items || []).some(item => item.productId === pendingDeleteProductId));

    if (wasUsed) {
      // Historical invoices exist; explain that invoice records are completely safe
      // but deleting will remove it from future billing.
      console.log(`Product ${pendingDeleteProductId} was used in past invoices. Deleting catalog record.`);
    }

    await db.deleteItem('products', pendingDeleteProductId);
    Utils.closeModal('deleteProductModal');
    Utils.showToast('Product removed from catalog.', 'success');
    pendingDeleteProductId = null;
    await loadProducts();
  } catch (err) {
    console.error('Error deleting product:', err);
    Utils.showToast('Failed to delete product.', 'error');
  }
}

/**
 * Event Listeners
 */
function setupProductEventListeners() {
  const addBtn = document.getElementById('addNewProductBtn');
  if (addBtn) addBtn.addEventListener('click', openAddProductModal);

  const form = document.getElementById('productForm');
  if (form) form.addEventListener('submit', saveProductForm);

  const searchInput = document.getElementById('productSearchInput');
  if (searchInput) searchInput.addEventListener('input', Utils.debounce(applyProductFilters, 200));

  ['categoryFilter', 'stockStatusFilter', 'productSortFilter'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('change', applyProductFilters);
  });

  const confirmDeleteBtn = document.getElementById('confirmDeleteProductBtn');
  if (confirmDeleteBtn) confirmDeleteBtn.addEventListener('click', executeDeleteProduct);
}

/**
 * SmartBill - Receipt & Invoice Printing Engine
 * Generates Standard A4 Invoice and POS Thermal 80mm Receipt formats.
 */

const ReceiptManager = {
  currentInvoice: null,
  currentFormat: 'a4', // 'a4' or 'thermal'

  /**
   * Opens the Receipt Preview Modal for a given invoice.
   */
  async showPreview(invoiceOrId, defaultFormat = 'a4') {
    let invoice = invoiceOrId;
    if (typeof invoiceOrId === 'string' || typeof invoiceOrId === 'number') {
      invoice = await db.getById('invoices', invoiceOrId);
      if (!invoice) {
        // Try searching by invoiceNumber
        const byNum = await db.getByIndex('invoices', 'invoiceNumber', invoiceOrId);
        if (byNum && byNum.length > 0) invoice = byNum[0];
      }
    }

    if (!invoice) {
      Utils.showToast('Could not load invoice data for receipt preview.', 'error');
      return;
    }

    this.currentInvoice = invoice;
    this.currentFormat = defaultFormat;

    // Ensure preview modal exists in the DOM
    this.ensurePreviewModal();

    // Render receipt content
    await this.renderReceipt();

    // Update active format button
    const formatBtns = document.querySelectorAll('.receipt-type-btn');
    formatBtns.forEach(btn => {
      if (btn.dataset.format === this.currentFormat) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });

    // Open modal
    Utils.openModal('receiptPreviewModal');
  },

  /**
   * Switches format between 'a4' and 'thermal'.
   */
  async switchFormat(format) {
    this.currentFormat = format;
    const formatBtns = document.querySelectorAll('.receipt-type-btn');
    formatBtns.forEach(btn => {
      btn.classList.toggle('active', btn.dataset.format === format);
    });
    await this.renderReceipt();
  },

  /**
   * Triggers the native browser print dialog.
   */
  printCurrentReceipt() {
    window.print();
  },

  /**
   * Renders the receipt HTML into the preview container.
   */
  async renderReceipt() {
    const previewContainer = document.getElementById('receiptPreviewContent');
    if (!previewContainer || !this.currentInvoice) return;

    const settings = await db.getAllSettings();
    const inv = this.currentInvoice;
    const sym = settings.currencySymbol || '$';
    const dec = parseInt(settings.decimalPrecision || 2, 10);

    if (this.currentFormat === 'thermal') {
      previewContainer.innerHTML = this.buildThermalHTML(inv, settings, sym, dec);
    } else {
      previewContainer.innerHTML = this.buildA4HTML(inv, settings, sym, dec);
    }
  },

  /**
   * Builds Standard A4 Invoice HTML
   */
  buildA4HTML(inv, settings, sym, dec) {
    const logoHTML = settings.businessLogo
      ? `<img src="${settings.businessLogo}" alt="Logo" class="a4-logo">`
      : '';

    const badgeClass = inv.paymentStatus === 'Paid' ? 'badge-paid' : (inv.paymentStatus === 'Partial' ? 'badge-partial' : 'badge-unpaid');

    const itemsRows = (inv.items || []).map((item, idx) => {
      const lineDisc = item.discount ? ` (Disc: -${Utils.formatCurrency(item.discount, sym, dec)})` : '';
      return `
        <tr>
          <td class="text-center" style="width: 40px;">${idx + 1}</td>
          <td>
            <strong>${Utils.escapeHTML(item.name)}</strong>
            ${item.sku ? `<div style="font-size:0.75rem; color:#6b7280;">SKU: ${Utils.escapeHTML(item.sku)}</div>` : ''}
          </td>
          <td class="text-center">${item.quantity}</td>
          <td class="text-right">${Utils.formatCurrency(item.unitPrice, sym, dec)}</td>
          <td class="text-right">${item.taxRate ? `${item.taxRate}%` : '0%'}</td>
          <td class="text-right"><strong>${Utils.formatCurrency(item.lineTotal, sym, dec)}</strong>${lineDisc}</td>
        </tr>
      `;
    }).join('');

    const customer = inv.customerSnapshot || {};

    return `
      <div class="receipt-paper format-a4">
        <!-- Header -->
        <div class="a4-header">
          <div class="a4-brand">
            ${logoHTML}
            <div class="a4-brand-info">
              <h1>${Utils.escapeHTML(settings.businessName || 'Apex Retail')}</h1>
              <p>${Utils.escapeHTML(settings.businessAddress || '')}</p>
              <p>Phone: ${Utils.escapeHTML(settings.businessPhone || '')} | Email: ${Utils.escapeHTML(settings.businessEmail || '')}</p>
              ${settings.businessTaxNo ? `<p>Tax / VAT Reg: <strong>${Utils.escapeHTML(settings.businessTaxNo)}</strong></p>` : ''}
            </div>
          </div>
          <div class="a4-invoice-meta">
            <h2 class="a4-invoice-title">INVOICE</h2>
            <div style="font-size: 1.1rem; font-weight: 700; color: #1e3a8a; margin-top: 0.25rem;">
              # ${Utils.escapeHTML(inv.invoiceNumber)}
            </div>
            <div style="margin-top: 0.4rem;">
              <span class="badge ${badgeClass}">${inv.paymentStatus || 'Paid'}</span>
            </div>
          </div>
        </div>

        <!-- Info Grid -->
        <div class="a4-info-grid">
          <div class="a4-info-block">
            <h3>Billed To (Customer):</h3>
            <p class="bold">${Utils.escapeHTML(customer.name || 'Walk-in Customer')}</p>
            ${customer.phone && customer.phone !== '-' ? `<p>Phone: ${Utils.escapeHTML(customer.phone)}</p>` : ''}
            ${customer.email && customer.email !== '-' ? `<p>Email: ${Utils.escapeHTML(customer.email)}</p>` : ''}
            ${customer.address && customer.address !== '-' ? `<p>Address: ${Utils.escapeHTML(customer.address)}</p>` : ''}
          </div>
          <div class="a4-info-block" style="text-align: right;">
            <h3>Invoice Details:</h3>
            <p><strong>Date:</strong> ${Utils.formatDate(inv.date)}</p>
            <p><strong>Time:</strong> ${inv.time || Utils.formatTime(inv.createdAt)}</p>
            <p><strong>Payment Method:</strong> ${Utils.escapeHTML(inv.paymentMethod || 'Cash')}</p>
          </div>
        </div>

        <!-- Line Items Table -->
        <table class="a4-table">
          <thead>
            <tr>
              <th class="text-center">#</th>
              <th>Item Description</th>
              <th class="text-center">Qty</th>
              <th class="text-right">Unit Price</th>
              <th class="text-right">Tax</th>
              <th class="text-right">Total</th>
            </tr>
          </thead>
          <tbody>
            ${itemsRows}
          </tbody>
        </table>

        <!-- Totals Area -->
        <div class="a4-totals-wrapper">
          <div class="a4-totals-box">
            <div class="a4-totals-row">
              <span>Subtotal:</span>
              <span>${Utils.formatCurrency(inv.subtotal, sym, dec)}</span>
            </div>
            ${inv.discount > 0 ? `
              <div class="a4-totals-row" style="color: #ef4444;">
                <span>Discount:</span>
                <span>-${Utils.formatCurrency(inv.discount, sym, dec)}</span>
              </div>
            ` : ''}
            <div class="a4-totals-row">
              <span>Tax / VAT:</span>
              <span>+${Utils.formatCurrency(inv.tax, sym, dec)}</span>
            </div>
            <div class="a4-totals-row grand-total">
              <span>Grand Total:</span>
              <span>${Utils.formatCurrency(inv.grandTotal, sym, dec)}</span>
            </div>
            <div class="a4-totals-row">
              <span>Amount Paid:</span>
              <span>${Utils.formatCurrency(inv.paidAmount, sym, dec)}</span>
            </div>
            ${inv.changeReturned > 0 ? `
              <div class="a4-totals-row">
                <span>Change Returned:</span>
                <span>${Utils.formatCurrency(inv.changeReturned, sym, dec)}</span>
              </div>
            ` : ''}
            ${inv.remainingBalance > 0 ? `
              <div class="a4-totals-row balance" style="color: #ef4444;">
                <span>Balance Due:</span>
                <span>${Utils.formatCurrency(inv.remainingBalance, sym, dec)}</span>
              </div>
            ` : ''}
          </div>
        </div>

        ${inv.notes ? `
          <div style="margin-top: 1.5rem; padding: 0.75rem; background: #f9fafb; border-radius: 4px; font-size: 0.85rem; border-left: 3px solid #1e3a8a;">
            <strong>Notes / Terms:</strong> ${Utils.escapeHTML(inv.notes)}
          </div>
        ` : ''}

        <!-- Footer -->
        <div class="a4-footer">
          <p>${Utils.escapeHTML(settings.invoiceFooter || 'Thank you for your business!')}</p>
          <div style="margin-top: 1.5rem; display: flex; justify-content: space-between; font-size: 0.75rem; color: #9ca3af;">
            <span>Generated electronically by SmartBill POS</span>
            <span>Authorized Signature: _______________________</span>
          </div>
        </div>
      </div>
    `;
  },

  /**
   * Builds Compact POS Thermal 80mm Receipt HTML
   */
  buildThermalHTML(inv, settings, sym, dec) {
    const customer = inv.customerSnapshot || {};

    const itemsRows = (inv.items || []).map(item => `
      <tr>
        <td colspan="2" style="font-weight: bold; padding-top: 4px;">${Utils.escapeHTML(item.name)}</td>
      </tr>
      <tr>
        <td style="color:#555; font-size:11px;">
          ${item.quantity} x ${Utils.formatCurrency(item.unitPrice, sym, dec)}
          ${item.discount ? ` (Disc -${item.discount})` : ''}
        </td>
        <td style="text-align:right; font-weight:bold;">${Utils.formatCurrency(item.lineTotal, sym, dec)}</td>
      </tr>
    `).join('');

    return `
      <div class="receipt-paper format-thermal">
        <div class="thermal-center">
          <div class="thermal-store-name">${Utils.escapeHTML(settings.businessName || 'Apex Retail')}</div>
          <div class="thermal-meta">${Utils.escapeHTML(settings.businessAddress || '')}</div>
          <div class="thermal-meta">Tel: ${Utils.escapeHTML(settings.businessPhone || '')}</div>
          ${settings.businessTaxNo ? `<div class="thermal-meta">Tax ID: ${Utils.escapeHTML(settings.businessTaxNo)}</div>` : ''}
        </div>

        <div class="thermal-divider"></div>

        <div class="thermal-row">
          <span>Receipt #:</span>
          <span class="bold">${Utils.escapeHTML(inv.invoiceNumber)}</span>
        </div>
        <div class="thermal-row">
          <span>Date/Time:</span>
          <span>${inv.date} ${inv.time || ''}</span>
        </div>
        <div class="thermal-row">
          <span>Customer:</span>
          <span>${Utils.escapeHTML(customer.name || 'Walk-in')}</span>
        </div>

        <div class="thermal-divider"></div>

        <table class="thermal-table">
          ${itemsRows}
        </table>

        <div class="thermal-divider"></div>

        <div class="thermal-row">
          <span>Subtotal:</span>
          <span>${Utils.formatCurrency(inv.subtotal, sym, dec)}</span>
        </div>
        ${inv.discount > 0 ? `
          <div class="thermal-row">
            <span>Discount:</span>
            <span>-${Utils.formatCurrency(inv.discount, sym, dec)}</span>
          </div>
        ` : ''}
        <div class="thermal-row">
          <span>Tax:</span>
          <span>+${Utils.formatCurrency(inv.tax, sym, dec)}</span>
        </div>
        <div class="thermal-row grand-total">
          <span>TOTAL:</span>
          <span>${Utils.formatCurrency(inv.grandTotal, sym, dec)}</span>
        </div>
        <div class="thermal-row">
          <span>Paid (${Utils.escapeHTML(inv.paymentMethod || 'Cash')}):</span>
          <span>${Utils.formatCurrency(inv.paidAmount, sym, dec)}</span>
        </div>
        ${inv.changeReturned > 0 ? `
          <div class="thermal-row bold">
            <span>Change:</span>
            <span>${Utils.formatCurrency(inv.changeReturned, sym, dec)}</span>
          </div>
        ` : ''}
        ${inv.remainingBalance > 0 ? `
          <div class="thermal-row bold" style="color:red;">
            <span>Balance Due:</span>
            <span>${Utils.formatCurrency(inv.remainingBalance, sym, dec)}</span>
          </div>
        ` : ''}

        <div class="thermal-divider"></div>

        <div class="thermal-center" style="margin: 10px 0;">
          <!-- Simple CSS/SVG Barcode Simulation -->
          <svg style="height: 36px; width: 160px; margin: 0 auto; display: block;" viewBox="0 0 160 36">
            <rect x="5" width="2" height="36" fill="#000"/>
            <rect x="9" width="3" height="36" fill="#000"/>
            <rect x="15" width="1" height="36" fill="#000"/>
            <rect x="18" width="4" height="36" fill="#000"/>
            <rect x="25" width="2" height="36" fill="#000"/>
            <rect x="30" width="3" height="36" fill="#000"/>
            <rect x="36" width="1" height="36" fill="#000"/>
            <rect x="40" width="2" height="36" fill="#000"/>
            <rect x="45" width="4" height="36" fill="#000"/>
            <rect x="52" width="2" height="36" fill="#000"/>
            <rect x="58" width="1" height="36" fill="#000"/>
            <rect x="62" width="3" height="36" fill="#000"/>
            <rect x="68" width="2" height="36" fill="#000"/>
            <rect x="73" width="4" height="36" fill="#000"/>
            <rect x="80" width="1" height="36" fill="#000"/>
            <rect x="84" width="3" height="36" fill="#000"/>
            <rect x="90" width="2" height="36" fill="#000"/>
            <rect x="95" width="3" height="36" fill="#000"/>
            <rect x="101" width="1" height="36" fill="#000"/>
            <rect x="105" width="4" height="36" fill="#000"/>
            <rect x="112" width="2" height="36" fill="#000"/>
            <rect x="118" width="3" height="36" fill="#000"/>
            <rect x="124" width="1" height="36" fill="#000"/>
            <rect x="128" width="4" height="36" fill="#000"/>
            <rect x="135" width="2" height="36" fill="#000"/>
            <rect x="140" width="3" height="36" fill="#000"/>
            <rect x="146" width="1" height="36" fill="#000"/>
            <rect x="150" width="2" height="36" fill="#000"/>
          </svg>
          <div style="font-size: 9px; letter-spacing: 2px; margin-top: 2px;">* ${Utils.escapeHTML(inv.invoiceNumber)} *</div>
        </div>

        <div class="thermal-footer">
          <div>${Utils.escapeHTML(settings.invoiceFooter || 'Thank you for shopping!')}</div>
          <div style="margin-top: 4px; font-size: 10px;">Please retain for your records.</div>
        </div>
      </div>
    `;
  },

  /**
   * Injects the Receipt Preview Modal into the body if it doesn't already exist.
   */
  ensurePreviewModal() {
    let modal = document.getElementById('receiptPreviewModal');
    if (modal) return;

    modal = document.createElement('div');
    modal.id = 'receiptPreviewModal';
    modal.className = 'modal-backdrop';

    modal.innerHTML = `
      <div class="modal modal-lg">
        <div class="modal-header">
          <div style="display: flex; align-items: center; gap: 1rem;">
            <h3 class="modal-title">Receipt & Invoice Preview</h3>
            <div class="receipt-type-toggle" style="margin-bottom: 0;">
              <button type="button" class="receipt-type-btn active" data-format="a4">Standard (A4)</button>
              <button type="button" class="receipt-type-btn" data-format="thermal">POS Thermal (80mm)</button>
            </div>
          </div>
          <button type="button" class="modal-close" data-modal-close aria-label="Close modal">&times;</button>
        </div>
        <div class="modal-body" style="padding: 1rem; background-color: var(--bg-surface-secondary);">
          <div class="receipt-preview-wrapper" id="receiptPreviewContainer">
            <div id="receiptPreviewContent"></div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-modal-close>Close</button>
          <button type="button" class="btn btn-primary" id="receiptPrintBtn">
            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4H7v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" />
            </svg>
            Print Receipt
          </button>
        </div>
      </div>
    `;

    document.body.appendChild(modal);

    // Event listener for format toggling
    modal.querySelectorAll('.receipt-type-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const format = e.currentTarget.dataset.format;
        ReceiptManager.switchFormat(format);
      });
    });

    // Event listener for print trigger
    const printBtn = modal.querySelector('#receiptPrintBtn');
    if (printBtn) {
      printBtn.addEventListener('click', () => {
        ReceiptManager.printCurrentReceipt();
      });
    }
  }
};

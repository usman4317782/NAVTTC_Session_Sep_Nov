/**
 * SmartBill - Invoices & Billing History Controller
 * Search, multi-criteria filtering, sorting, pagination, duplicate, safe delete & print.
 */

let allInvoices = [];
let filteredInvoices = [];
let currentPage = 1;
const PAGE_SIZE = 10;
let pendingDeleteId = null;

document.addEventListener('DOMContentLoaded', async () => {
  await db.initDB();
  await loadInvoices();
  setupFilterListeners();
});

async function loadInvoices() {
  try {
    allInvoices = await db.getAll('invoices');
    // Default sort: newest first
    allInvoices.sort((a, b) => new Date(b.createdAt || b.date) - new Date(a.createdAt || a.date));
    applyFilters();
  } catch (err) {
    console.error('Error loading invoices:', err);
    Utils.showToast('Failed to load invoices from database.', 'error');
  }
}

/**
 * Filter & Sort Logic
 */
function applyFilters() {
  const search = (document.getElementById('invoiceSearchInput')?.value || '').toLowerCase().trim();
  const status = document.getElementById('statusFilter')?.value || 'all';
  const method = document.getElementById('methodFilter')?.value || 'all';
  const fromDate = document.getElementById('fromDateFilter')?.value || '';
  const toDate = document.getElementById('toDateFilter')?.value || '';
  const sort = document.getElementById('sortFilter')?.value || 'newest';

  filteredInvoices = allInvoices.filter(inv => {
    // Search query matches invoiceNumber, customer name, customer phone
    if (search) {
      const invNo = (inv.invoiceNumber || '').toLowerCase();
      const cName = (inv.customerSnapshot?.name || '').toLowerCase();
      const cPhone = (inv.customerSnapshot?.phone || '').toLowerCase();
      if (!invNo.includes(search) && !cName.includes(search) && !cPhone.includes(search)) {
        return false;
      }
    }

    // Payment Status filter
    if (status !== 'all' && inv.paymentStatus !== status) {
      return false;
    }

    // Payment Method filter
    if (method !== 'all' && inv.paymentMethod !== method) {
      return false;
    }

    // Date range filter
    if (fromDate && inv.date < fromDate) return false;
    if (toDate && inv.date > toDate) return false;

    return true;
  });

  // Sorting
  if (sort === 'newest') {
    filteredInvoices.sort((a, b) => new Date(b.createdAt || b.date) - new Date(a.createdAt || a.date));
  } else if (sort === 'oldest') {
    filteredInvoices.sort((a, b) => new Date(a.createdAt || a.date) - new Date(b.createdAt || b.date));
  } else if (sort === 'highest') {
    filteredInvoices.sort((a, b) => (Number(b.grandTotal) || 0) - (Number(a.grandTotal) || 0));
  } else if (sort === 'lowest') {
    filteredInvoices.sort((a, b) => (Number(a.grandTotal) || 0) - (Number(b.grandTotal) || 0));
  }

  currentPage = 1;
  renderInvoicesTable();
}

/**
 * Renders the invoice table with pagination
 */
async function renderInvoicesTable() {
  const tbody = document.getElementById('invoicesTableBody');
  const countBadge = document.getElementById('totalInvoiceCount');
  if (!tbody) return;

  const settings = await db.getAllSettings();
  const sym = settings.currencySymbol || '$';
  const dec = parseInt(settings.decimalPrecision || 2, 10);

  if (countBadge) {
    countBadge.textContent = `${filteredInvoices.length} of ${allInvoices.length}`;
  }

  if (filteredInvoices.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="8">
          <div class="empty-state">
            <div class="empty-state-icon">
              <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
            </div>
            <div class="empty-state-title">No Invoices Found</div>
            <p class="empty-state-desc">Try modifying your search query, date ranges, or status filters.</p>
            <button class="btn btn-secondary btn-sm" onclick="clearFilters()">Reset Filters</button>
          </div>
        </td>
      </tr>
    `;
    renderPagination(0);
    return;
  }

  // Slice for current page
  const totalPages = Math.ceil(filteredInvoices.length / PAGE_SIZE);
  const start = (currentPage - 1) * PAGE_SIZE;
  const pageItems = filteredInvoices.slice(start, start + PAGE_SIZE);

  tbody.innerHTML = pageItems.map(inv => {
    const cust = inv.customerSnapshot || {};
    const badgeClass = inv.paymentStatus === 'Paid' ? 'badge-paid' : (inv.paymentStatus === 'Partial' ? 'badge-partial' : 'badge-unpaid');

    return `
      <tr>
        <td>
          <a href="#" onclick="ReceiptManager.showPreview('${inv.id}'); return false;" style="font-weight:700; color:var(--primary);">
            ${Utils.escapeHTML(inv.invoiceNumber)}
          </a>
        </td>
        <td>
          <div>${Utils.formatDate(inv.date)}</div>
          <div style="font-size:0.75rem; color:var(--text-muted);">${inv.time || ''}</div>
        </td>
        <td>
          <div style="font-weight:600;">${Utils.escapeHTML(cust.name || 'Walk-in')}</div>
          <div style="font-size:0.75rem; color:var(--text-muted);">${Utils.escapeHTML(cust.phone || '')}</div>
        </td>
        <td>${(inv.items || []).length} items</td>
        <td style="font-weight:700; font-size:0.95rem;">${Utils.formatCurrency(inv.grandTotal, sym, dec)}</td>
        <td>
          <div>${Utils.formatCurrency(inv.paidAmount, sym, dec)}</div>
          ${inv.remainingBalance > 0 ? `<div style="font-size:0.75rem; color:var(--danger);">Bal: ${Utils.formatCurrency(inv.remainingBalance, sym, dec)}</div>` : ''}
        </td>
        <td>
          <span class="badge ${badgeClass}"><span class="badge-dot"></span>${inv.paymentStatus || 'Paid'}</span>
          <div style="font-size:0.725rem; color:var(--text-muted); margin-top:2px;">${Utils.escapeHTML(inv.paymentMethod || 'Cash')}</div>
        </td>
        <td>
          <div class="table-actions">
            <button class="btn btn-secondary btn-sm" onclick="ReceiptManager.showPreview('${inv.id}')" title="Print / Preview Receipt">
              <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" style="width:14px;height:14px;"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4H7v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"/></svg>
              Print
            </button>
            <button class="btn btn-secondary btn-sm" onclick="duplicateInvoice('${inv.id}')" title="Duplicate this invoice">
              <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" style="width:14px;height:14px;"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"/></svg>
            </button>
            <button class="btn btn-icon btn-sm" style="color:var(--danger);" onclick="promptDeleteInvoice('${inv.id}')" title="Delete Invoice">
              <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" style="width:14px;height:14px;"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
            </button>
          </div>
        </td>
      </tr>
    `;
  }).join('');

  renderPagination(totalPages);
}

/**
 * Pagination Controls
 */
function renderPagination(totalPages) {
  const paginationContainer = document.getElementById('invoicesPagination');
  if (!paginationContainer) return;

  if (totalPages <= 1) {
    paginationContainer.innerHTML = '';
    return;
  }

  let html = `
    <div style="display:flex; align-items:center; justify-content:space-between; width:100%; padding:0.5rem 0;">
      <div style="font-size:0.85rem; color:var(--text-secondary);">
        Page <strong>${currentPage}</strong> of <strong>${totalPages}</strong>
      </div>
      <div style="display:flex; gap:0.5rem;">
        <button class="btn btn-secondary btn-sm" ${currentPage === 1 ? 'disabled' : ''} onclick="changePage(${currentPage - 1})">
          &laquo; Previous
        </button>
        <button class="btn btn-secondary btn-sm" ${currentPage === totalPages ? 'disabled' : ''} onclick="changePage(${currentPage + 1})">
          Next &raquo;
        </button>
      </div>
    </div>
  `;

  paginationContainer.innerHTML = html;
}

function changePage(page) {
  currentPage = page;
  renderInvoicesTable();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

/**
 * Setup Filter Inputs Listeners
 */
function setupFilterListeners() {
  const searchInput = document.getElementById('invoiceSearchInput');
  if (searchInput) {
    searchInput.addEventListener('input', Utils.debounce(applyFilters, 200));
  }

  ['statusFilter', 'methodFilter', 'sortFilter', 'fromDateFilter', 'toDateFilter'].forEach(id => {
    const el = document.getElementById(id);
    if (el) {
      el.addEventListener('change', applyFilters);
    }
  });

  // Delete modal confirm button
  const confirmDeleteBtn = document.getElementById('confirmDeleteInvoiceBtn');
  if (confirmDeleteBtn) {
    confirmDeleteBtn.addEventListener('click', executeDeleteInvoice);
  }
}

function clearFilters() {
  document.getElementById('invoiceSearchInput').value = '';
  document.getElementById('statusFilter').value = 'all';
  document.getElementById('methodFilter').value = 'all';
  document.getElementById('fromDateFilter').value = '';
  document.getElementById('toDateFilter').value = '';
  document.getElementById('sortFilter').value = 'newest';
  applyFilters();
}

/**
 * Duplicate invoice: stores items and customer in localStorage, then redirects to billing.html
 */
async function duplicateInvoice(id) {
  const inv = allInvoices.find(i => i.id === id);
  if (!inv) return;

  const cloneData = {
    customerId: inv.customerId,
    items: inv.items.map(item => ({ ...item })),
    notes: `Duplicated from #${inv.invoiceNumber}`
  };

  localStorage.setItem('smartbill_draft_invoice', JSON.stringify(cloneData));
  Utils.showToast(`Duplicating Invoice #${inv.invoiceNumber}...`, 'info');
  setTimeout(() => {
    window.location.href = 'billing.html';
  }, 300);
}

/**
 * Prompt to delete an invoice
 */
function promptDeleteInvoice(id) {
  const inv = allInvoices.find(i => i.id === id);
  if (!inv) return;

  pendingDeleteId = id;
  const numSpan = document.getElementById('deleteInvoiceNumber');
  if (numSpan) numSpan.textContent = inv.invoiceNumber;

  Utils.openModal('deleteInvoiceModal');
}

/**
 * Executes deletion of an invoice with optional inventory restore
 */
async function executeDeleteInvoice() {
  if (!pendingDeleteId) return;

  try {
    const inv = allInvoices.find(i => i.id === pendingDeleteId);
    const restoreStock = document.getElementById('restoreInventoryCheckbox')?.checked;

    if (inv && restoreStock) {
      for (const item of (inv.items || [])) {
        if (item.productId) {
          const prod = await db.getById('products', item.productId);
          if (prod) {
            prod.stockQuantity = (Number(prod.stockQuantity) || 0) + (Number(item.quantity) || 0);
            await db.put('products', prod);
          }
        }
      }
    }

    await db.deleteItem('invoices', pendingDeleteId);
    Utils.closeModal('deleteInvoiceModal');
    Utils.showToast('Invoice deleted successfully.', 'success');

    pendingDeleteId = null;
    await loadInvoices();
  } catch (err) {
    console.error('Error deleting invoice:', err);
    Utils.showToast('Failed to delete invoice.', 'error');
  }
}

/**
 * SmartBill - Shared Application Shell Controller
 * Navigation, Theme Toggle, Mobile Drawer, Header Real-Time Clock & Branding Sync.
 */

document.addEventListener('DOMContentLoaded', async () => {
  // 1. Initialize DB and sync business branding
  try {
    await db.initDB();
    await syncBusinessBranding();
  } catch (err) {
    console.warn('DB initialization error in app shell:', err);
  }

  // 2. Active Navigation Highlight
  highlightActiveNav();

  // 3. Setup Theme Toggle & Restore Preference
  initThemeManager();

  // 4. Setup Mobile Navigation Drawer
  initMobileDrawer();

  // 5. Setup Header Real-Time Clock
  initHeaderClock();
});

/**
 * Highlights current page link in sidebar navigation
 */
function highlightActiveNav() {
  const currentPath = window.location.pathname;
  const pageFilename = currentPath.split('/').pop() || 'index.html';

  const navLinks = document.querySelectorAll('.sidebar-nav .nav-link');
  navLinks.forEach(link => {
    const href = link.getAttribute('href');
    if (href === pageFilename || (pageFilename === '' && href === 'index.html')) {
      link.classList.add('active');
    } else {
      link.classList.remove('active');
    }
  });
}

/**
 * Theme Manager: Supports Light, Dark, and System preference
 */
function initThemeManager() {
  const savedTheme = localStorage.getItem('smartbill_theme') || 'light';
  applyTheme(savedTheme);

  const themeToggleBtn = document.getElementById('themeToggleBtn');
  if (themeToggleBtn) {
    themeToggleBtn.addEventListener('click', () => {
      const current = document.documentElement.getAttribute('data-theme') || 'light';
      const next = current === 'dark' ? 'light' : 'dark';
      applyTheme(next);
      localStorage.setItem('smartbill_theme', next);
    });
  }

  // Listen for OS system theme changes if set to auto
  if (window.matchMedia) {
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', e => {
      if (localStorage.getItem('smartbill_theme') === 'system') {
        applyTheme(e.matches ? 'dark' : 'light');
      }
    });
  }
}

function applyTheme(theme) {
  let activeTheme = theme;
  if (theme === 'system') {
    activeTheme = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  }

  document.documentElement.setAttribute('data-theme', activeTheme);

  // Update theme toggle button icon if present
  const themeToggleBtn = document.getElementById('themeToggleBtn');
  if (themeToggleBtn) {
    if (activeTheme === 'dark') {
      // Show Sun icon for switching to light
      themeToggleBtn.innerHTML = `
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" />
        </svg>
      `;
      themeToggleBtn.title = 'Switch to Light Mode';
    } else {
      // Show Moon icon for switching to dark
      themeToggleBtn.innerHTML = `
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" 
                d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
        </svg>
      `;
      themeToggleBtn.title = 'Switch to Dark Mode';
    }
  }
}

/**
 * Mobile Drawer Menu Handlers
 */
function initMobileDrawer() {
  const menuBtn = document.getElementById('menuToggleBtn');
  const sidebar = document.querySelector('.app-sidebar');
  let backdrop = document.querySelector('.sidebar-backdrop');

  if (!backdrop) {
    backdrop = document.createElement('div');
    backdrop.className = 'sidebar-backdrop';
    document.body.appendChild(backdrop);
  }

  if (menuBtn && sidebar) {
    menuBtn.addEventListener('click', () => {
      sidebar.classList.toggle('open');
      backdrop.classList.toggle('active');
    });

    backdrop.addEventListener('click', () => {
      sidebar.classList.remove('open');
      backdrop.classList.remove('active');
    });

    // Close on navigation link click on mobile
    const links = sidebar.querySelectorAll('.nav-link, .quick-bill-btn');
    links.forEach(l => {
      l.addEventListener('click', () => {
        if (window.innerWidth <= 768) {
          sidebar.classList.remove('open');
          backdrop.classList.remove('active');
        }
      });
    });
  }
}

/**
 * Real-time clock in header
 */
function initHeaderClock() {
  const clockEl = document.getElementById('headerClock');
  if (!clockEl) return;

  const update = () => {
    const now = new Date();
    const timeStr = now.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    });
    const dateStr = now.toLocaleDateString('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric'
    });
    clockEl.textContent = `${dateStr} • ${timeStr}`;
  };

  update();
  setInterval(update, 1000);
}

/**
 * Synchronizes business profile branding in header and sidebar
 */
async function syncBusinessBranding() {
  const businessName = await db.getSetting('businessName', 'Apex Retail');
  const businessLogo = await db.getSetting('businessLogo', '');

  // Update header text
  const headerNameEl = document.querySelector('.business-header-name');
  if (headerNameEl) {
    headerNameEl.textContent = businessName;
  }

  // Update sidebar branding title if available
  const sidebarTitleEl = document.querySelector('.brand-title');
  if (sidebarTitleEl) {
    sidebarTitleEl.textContent = businessName;
  }

  // Update logo avatars if custom logo image exists
  if (businessLogo) {
    const headerAvatar = document.querySelector('.business-avatar');
    if (headerAvatar) {
      headerAvatar.innerHTML = `<img src="${businessLogo}" alt="Logo" style="width:100%;height:100%;object-fit:cover;border-radius:50%;">`;
    }
  } else {
    // Show initials
    const initials = businessName.split(' ').map(w => w[0]).join('').substr(0, 2).toUpperCase() || 'SB';
    const headerAvatar = document.querySelector('.business-avatar');
    if (headerAvatar) {
      headerAvatar.textContent = initials;
    }
  }
}

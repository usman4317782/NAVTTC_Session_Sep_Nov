/**
 * SmartBill - Billing & POS Controller
 * Handles product selection, dynamic line items, real-time calculations,
 * stock deduction, customer selection & quick-add, and invoice persistence.
 */

let billingState = {
  invoiceNumber: '',
  date: '',
  time: '',
  customerId: 'walk-in',
  customerSnapshot: {
    name: 'Walk-in Customer',
    phone: '-',
    email: '-',
    address: '-'
  },
  items: [],
  overallDiscount: 0,
  taxRate: 8.5,
  paidAmount: 0,
  paymentMethod: 'Cash',
  notes: '',
  inventoryTracking: true
};

let allProductsCache = [];
let allCustomersCache = [];

document.addEventListener('DOMContentLoaded', async () => {
  await db.initDB();
  await initBillingPage();
});

async function initBillingPage() {
  const settings = await db.getAllSettings();
  billingState.taxRate = Number(settings.defaultTaxRate) || 0;
  billingState.overallDiscount = Number(settings.defaultDiscount) || 0;
  billingState.paymentMethod = settings.defaultPaymentMethod || 'Cash';
  billingState.inventoryTracking = settings.inventoryTracking !== false;

  // Set date and time
  billingState.date = Utils.getCurrentDateISO();
  billingState.time = Utils.getCurrentTimeStr();

  const invoiceDateInput = document.getElementById('invoiceDate');
  if (invoiceDateInput) invoiceDateInput.value = billingState.date;

  const invoiceNumberInput = document.getElementById('invoiceNumber');
  billingState.invoiceNumber = await db.getNextInvoiceNumber();
  if (invoiceNumberInput) invoiceNumberInput.value = billingState.invoiceNumber;

  // Cache products and customers
  allProductsCache = await db.getAll('products');
  allCustomersCache = await db.getAll('customers');

  // Populate Customer Select
  populateCustomerSelect();

  // Setup Product Search Autocomplete
  setupProductSearch();

  // Setup Payment Method Selection
  setupPaymentMethods();

  // Setup Event Listeners
  setupEventListeners();

  // Check for duplicate / draft invoice from localStorage
  const draftStr = localStorage.getItem('smartbill_draft_invoice');
  if (draftStr) {
    try {
      const draft = JSON.parse(draftStr);
      if (draft.customerId) {
        billingState.customerId = draft.customerId;
        const custSelect = document.getElementById('customerSelect');
        if (custSelect) custSelect.value = draft.customerId;
        handleCustomerChange(draft.customerId);
      }
      if (Array.isArray(draft.items)) {
        billingState.items = draft.items;
      }
      if (draft.notes) {
        const notesEl = document.getElementById('invoiceNotes');
        if (notesEl) notesEl.value = draft.notes;
      }
      localStorage.removeItem('smartbill_draft_invoice');
      Utils.showToast('Loaded duplicated invoice line items.', 'info');
    } catch (e) {
      console.warn('Error loading draft invoice:', e);
    }
  }

  // Render initial table & totals
  renderItemsTable();
  recalculateTotals();
}

/**
 * Populates customer dropdown with existing customers
 */
function populateCustomerSelect() {
  const select = document.getElementById('customerSelect');
  if (!select) return;

  select.innerHTML = `
    <option value="walk-in">Walk-in Customer</option>
    ${allCustomersCache.map(c => `
      <option value="${c.id}">${Utils.escapeHTML(c.name)} (${Utils.escapeHTML(c.phone || 'No phone')})</option>
    `).join('')}
  `;

  select.value = billingState.customerId;
}

/**
 * Handles customer change or auto-fill
 */
function handleCustomerChange(customerId) {
  billingState.customerId = customerId;

  if (customerId === 'walk-in') {
    billingState.customerSnapshot = {
      name: 'Walk-in Customer',
      phone: '-',
      email: '-',
      address: '-'
    };
    document.getElementById('custPhone').value = '';
    document.getElementById('custEmail').value = '';
    document.getElementById('custAddress').value = '';
  } else {
    const cust = allCustomersCache.find(c => c.id === customerId);
    if (cust) {
      billingState.customerSnapshot = {
        name: cust.name,
        phone: cust.phone || '-',
        email: cust.email || '-',
        address: cust.address || '-'
      };
      document.getElementById('custPhone').value = cust.phone || '';
      document.getElementById('custEmail').value = cust.email || '';
      document.getElementById('custAddress').value = cust.address || '';
    }
  }
}

/**
 * Product search autocomplete dropdown
 */
function setupProductSearch() {
  const searchInput = document.getElementById('productSearchInput');
  const resultsContainer = document.getElementById('productSearchResults');
  if (!searchInput || !resultsContainer) return;

  const performSearch = () => {
    const query = searchInput.value.trim().toLowerCase();
    if (!query) {
      resultsContainer.classList.remove('active');
      resultsContainer.innerHTML = '';
      return;
    }

    const matched = allProductsCache.filter(p => {
      if (p.isActive === false) return false;
      const name = (p.name || '').toLowerCase();
      const sku = (p.sku || '').toLowerCase();
      const cat = (p.category || '').toLowerCase();
      return name.includes(query) || sku.includes(query) || cat.includes(query);
    }).slice(0, 8);

    if (matched.length === 0) {
      resultsContainer.innerHTML = `
        <div style="padding: 0.85rem 1rem; color: var(--text-muted); font-size: 0.85rem; text-align: center;">
          No matching products found.
        </div>
      `;
      resultsContainer.classList.add('active');
      return;
    }

    resultsContainer.innerHTML = matched.map(p => `
      <div class="pos-product-item" data-id="${p.id}">
        <div>
          <div class="pos-item-name">${Utils.escapeHTML(p.name)}</div>
          <div class="pos-item-meta">SKU: ${Utils.escapeHTML(p.sku || '-')} • Stock: ${p.stockQuantity}</div>
        </div>
        <div class="pos-item-price">$${Number(p.sellingPrice || 0).toFixed(2)}</div>
      </div>
    `).join('');

    resultsContainer.classList.add('active');

    // Click on item
    resultsContainer.querySelectorAll('.pos-product-item').forEach(itemEl => {
      itemEl.addEventListener('click', () => {
        const prodId = itemEl.dataset.id;
        const prod = allProductsCache.find(p => p.id === prodId);
        if (prod) {
          addProductToInvoice(prod);
          searchInput.value = '';
          resultsContainer.classList.remove('active');
          searchInput.focus();
        }
      });
    });
  };

  searchInput.addEventListener('input', Utils.debounce(performSearch, 150));
  searchInput.addEventListener('focus', performSearch);

  // Close results on outside click
  document.addEventListener('click', (e) => {
    if (!searchInput.contains(e.target) && !resultsContainer.contains(e.target)) {
      resultsContainer.classList.remove('active');
    }
  });
}

/**
 * Adds product to the invoice line items
 */
function addProductToInvoice(product) {
  const existing = billingState.items.find(item => item.productId === product.id);

  if (existing) {
    if (billingState.inventoryTracking && existing.quantity >= product.stockQuantity) {
      Utils.showToast(`Warning: Only ${product.stockQuantity} units available in stock.`, 'warning');
    }
    existing.quantity += 1;
    existing.lineTotal = calculateLineTotal(existing);
  } else {
    const newItem = {
      id: Utils.generateId('item'),
      productId: product.id,
      name: product.name,
      sku: product.sku,
      unitPrice: Number(product.sellingPrice) || 0,
      quantity: 1,
      maxStock: product.stockQuantity,
      discount: 0,
      taxRate: billingState.taxRate,
      lineTotal: Number(product.sellingPrice) || 0
    };
    newItem.lineTotal = calculateLineTotal(newItem);
    billingState.items.push(newItem);
  }

  renderItemsTable();
  recalculateTotals();
  Utils.showToast(`Added "${product.name}" to invoice.`, 'info', 1500);
}

/**
 * Adds a custom line item
 */
function addCustomItem() {
  const customItem = {
    id: Utils.generateId('item'),
    productId: null,
    name: 'Custom Service / Item',
    sku: 'CUSTOM',
    unitPrice: 10.00,
    quantity: 1,
    maxStock: 9999,
    discount: 0,
    taxRate: billingState.taxRate,
    lineTotal: 10.00
  };
  billingState.items.push(customItem);
  renderItemsTable();
  recalculateTotals();
}

/**
 * Calculates individual line total
 */
function calculateLineTotal(item) {
  const base = (Number(item.quantity) || 0) * (Number(item.unitPrice) || 0);
  const afterDiscount = Math.max(0, base - (Number(item.discount) || 0));
  return Utils.roundCurrency(afterDiscount);
}

/**
 * Renders the invoice line items table
 */
function renderItemsTable() {
  const tbody = document.getElementById('billingItemsTableBody');
  if (!tbody) return;

  if (billingState.items.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="7">
          <div class="empty-state" style="padding: 2.5rem 1rem;">
            <div class="empty-state-icon" style="width:48px;height:48px;margin-bottom:0.75rem;">
              <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/></svg>
            </div>
            <div class="empty-state-title" style="font-size:1rem;">Invoice is Empty</div>
            <p class="empty-state-desc" style="font-size:0.8rem; margin-bottom:0.5rem;">Use the search bar above to add products, or add a custom service.</p>
            <button type="button" class="btn btn-secondary btn-sm" onclick="addCustomItem()">+ Add Custom Item</button>
          </div>
        </td>
      </tr>
    `;
    return;
  }

  tbody.innerHTML = billingState.items.map((item, idx) => `
    <tr data-item-id="${item.id}">
      <td style="width: 40px; text-align: center; color: var(--text-muted); font-size: 0.8rem;">${idx + 1}</td>
      <td>
        <input type="text" class="form-control item-name-input" value="${Utils.escapeHTML(item.name)}" style="font-weight:600; padding:0.4rem 0.6rem;">
        <div style="font-size:0.75rem; color:var(--text-muted); margin-top:2px;">SKU: ${Utils.escapeHTML(item.sku || '-')}</div>
      </td>
      <td style="width: 130px;">
        <div class="qty-stepper">
          <button type="button" class="qty-btn btn-qty-minus">-</button>
          <input type="number" class="qty-input" value="${item.quantity}" min="1" step="1">
          <button type="button" class="qty-btn btn-qty-plus">+</button>
        </div>
      </td>
      <td style="width: 120px;">
        <input type="number" class="form-control item-price-input" value="${item.unitPrice}" min="0" step="0.01" style="text-align:right; padding:0.4rem 0.6rem;">
      </td>
      <td style="width: 100px;">
        <input type="number" class="form-control item-disc-input" value="${item.discount}" min="0" step="0.01" style="text-align:right; padding:0.4rem 0.6rem;" title="Item discount in currency">
      </td>
      <td style="width: 120px; text-align: right; font-weight: 700; font-size: 0.95rem;">
        $${item.lineTotal.toFixed(2)}
      </td>
      <td style="width: 50px; text-align: center;">
        <button type="button" class="btn btn-icon btn-sm btn-item-remove" style="color:var(--danger);" title="Remove Item">
          <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
        </button>
      </td>
    </tr>
  `).join('');

  attachItemRowListeners();
}

/**
 * Attaches row-level input listeners
 */
function attachItemRowListeners() {
  const tbody = document.getElementById('billingItemsTableBody');
  if (!tbody) return;

  tbody.querySelectorAll('tr[data-item-id]').forEach(row => {
    const itemId = row.dataset.itemId;
    const item = billingState.items.find(i => i.id === itemId);
    if (!item) return;

    // Item Name Change
    row.querySelector('.item-name-input').addEventListener('change', (e) => {
      item.name = e.target.value.trim() || 'Unnamed Item';
    });

    // Quantity buttons & input
    const qtyInput = row.querySelector('.qty-input');
    row.querySelector('.btn-qty-minus').addEventListener('click', () => {
      if (item.quantity > 1) {
        item.quantity -= 1;
        qtyInput.value = item.quantity;
        item.lineTotal = calculateLineTotal(item);
        row.querySelector('td:nth-child(6)').textContent = `$${item.lineTotal.toFixed(2)}`;
        recalculateTotals();
      }
    });

    row.querySelector('.btn-qty-plus').addEventListener('click', () => {
      if (billingState.inventoryTracking && item.maxStock && item.quantity >= item.maxStock) {
        Utils.showToast(`Warning: Only ${item.maxStock} items in stock!`, 'warning');
      }
      item.quantity += 1;
      qtyInput.value = item.quantity;
      item.lineTotal = calculateLineTotal(item);
      row.querySelector('td:nth-child(6)').textContent = `$${item.lineTotal.toFixed(2)}`;
      recalculateTotals();
    });

    qtyInput.addEventListener('change', (e) => {
      const val = parseInt(e.target.value, 10);
      item.quantity = isNaN(val) || val < 1 ? 1 : val;
      qtyInput.value = item.quantity;
      item.lineTotal = calculateLineTotal(item);
      row.querySelector('td:nth-child(6)').textContent = `$${item.lineTotal.toFixed(2)}`;
      recalculateTotals();
    });

    // Price change
    row.querySelector('.item-price-input').addEventListener('change', (e) => {
      const p = parseFloat(e.target.value);
      item.unitPrice = isNaN(p) || p < 0 ? 0 : Utils.roundCurrency(p);
      item.lineTotal = calculateLineTotal(item);
      row.querySelector('td:nth-child(6)').textContent = `$${item.lineTotal.toFixed(2)}`;
      recalculateTotals();
    });

    // Discount change
    row.querySelector('.item-disc-input').addEventListener('change', (e) => {
      const d = parseFloat(e.target.value);
      item.discount = isNaN(d) || d < 0 ? 0 : Utils.roundCurrency(d);
      item.lineTotal = calculateLineTotal(item);
      row.querySelector('td:nth-child(6)').textContent = `$${item.lineTotal.toFixed(2)}`;
      recalculateTotals();
    });

    // Remove row
    row.querySelector('.btn-item-remove').addEventListener('click', () => {
      billingState.items = billingState.items.filter(i => i.id !== itemId);
      renderItemsTable();
      recalculateTotals();
    });
  });
}

/**
 * Recalculates all totals with precision
 */
function recalculateTotals() {
  let subtotal = 0;
  let lineDiscounts = 0;

  billingState.items.forEach(item => {
    subtotal += (Number(item.quantity) || 0) * (Number(item.unitPrice) || 0);
    lineDiscounts += Number(item.discount) || 0;
  });

  const overallDiscount = Number(billingState.overallDiscount) || 0;
  const totalDiscount = Utils.roundCurrency(lineDiscounts + overallDiscount);
  const taxableAmount = Math.max(0, subtotal - totalDiscount);
  const taxRate = Number(billingState.taxRate) || 0;
  const taxAmount = Utils.roundCurrency((taxableAmount * taxRate) / 100);
  const grandTotal = Utils.roundCurrency(taxableAmount + taxAmount);

  // Paid amount calculation
  const paid = Number(billingState.paidAmount) || 0;
  const remainingBalance = Utils.roundCurrency(Math.max(0, grandTotal - paid));
  const changeReturned = Utils.roundCurrency(Math.max(0, paid - grandTotal));

  // Determine payment status
  let paymentStatus = 'Paid';
  if (paid === 0 && grandTotal > 0) {
    paymentStatus = 'Unpaid';
  } else if (paid < grandTotal) {
    paymentStatus = 'Partial';
  }

  // Update UI Elements
  document.getElementById('summarySubtotal').textContent = `$${subtotal.toFixed(2)}`;
  document.getElementById('summaryDiscount').textContent = `-$${totalDiscount.toFixed(2)}`;
  document.getElementById('summaryTax').textContent = `+$${taxAmount.toFixed(2)}`;
  document.getElementById('summaryTaxRateLabel').textContent = `(${taxRate}%)`;
  document.getElementById('summaryGrandTotal').textContent = `$${grandTotal.toFixed(2)}`;
  document.getElementById('summaryBalanceDue').textContent = `$${remainingBalance.toFixed(2)}`;
  document.getElementById('summaryChange').textContent = `$${changeReturned.toFixed(2)}`;

  // Store computed values in state
  billingState.computed = {
    subtotal: Utils.roundCurrency(subtotal),
    discount: totalDiscount,
    tax: taxAmount,
    grandTotal: grandTotal,
    paidAmount: paid,
    remainingBalance: remainingBalance,
    changeReturned: changeReturned,
    paymentStatus: paymentStatus
  };

  // Update payment status badge in sidebar
  const statusBadge = document.getElementById('paymentStatusBadge');
  if (statusBadge) {
    statusBadge.textContent = paymentStatus;
    statusBadge.className = `badge ${paymentStatus === 'Paid' ? 'badge-paid' : (paymentStatus === 'Partial' ? 'badge-partial' : 'badge-unpaid')}`;
  }
}

/**
 * Setup Payment Method selector cards
 */
function setupPaymentMethods() {
  const methodCards = document.querySelectorAll('.payment-method-card');
  methodCards.forEach(card => {
    card.addEventListener('click', () => {
      methodCards.forEach(c => c.classList.remove('active'));
      card.classList.add('active');
      billingState.paymentMethod = card.dataset.method;
    });
  });
}

/**
 * Setup Global Page Event Listeners
 */
function setupEventListeners() {
  // Customer select change
  const customerSelect = document.getElementById('customerSelect');
  if (customerSelect) {
    customerSelect.addEventListener('change', (e) => {
      handleCustomerChange(e.target.value);
    });
  }

  // Quick Add Customer button
  const quickAddCustBtn = document.getElementById('quickAddCustBtn');
  if (quickAddCustBtn) {
    quickAddCustBtn.addEventListener('click', () => {
      document.getElementById('quickCustForm').reset();
      Utils.openModal('quickCustomerModal');
    });
  }

  // Quick Add Customer Save Form
  const quickCustForm = document.getElementById('quickCustForm');
  if (quickCustForm) {
    quickCustForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const name = document.getElementById('quickCustName').value.trim();
      const phone = document.getElementById('quickCustPhone').value.trim();
      const email = document.getElementById('quickCustEmail').value.trim();
      const address = document.getElementById('quickCustAddress').value.trim();

      if (!name) {
        Utils.showToast('Please enter customer name.', 'warning');
        return;
      }

      const newCust = {
        id: Utils.generateId('cust'),
        name,
        phone,
        email,
        address,
        createdAt: new Date().toISOString()
      };

      await db.put('customers', newCust);
      allCustomersCache.push(newCust);
      populateCustomerSelect();
      document.getElementById('customerSelect').value = newCust.id;
      handleCustomerChange(newCust.id);

      Utils.closeModal('quickCustomerModal');
      Utils.showToast(`Customer "${name}" created and selected!`, 'success');
    });
  }

  // Add Custom Item button
  const addCustomItemBtn = document.getElementById('addCustomItemBtn');
  if (addCustomItemBtn) {
    addCustomItemBtn.addEventListener('click', addCustomItem);
  }

  // Overall discount input
  const overallDiscountInput = document.getElementById('overallDiscountInput');
  if (overallDiscountInput) {
    overallDiscountInput.addEventListener('input', (e) => {
      billingState.overallDiscount = parseFloat(e.target.value) || 0;
      recalculateTotals();
    });
  }

  // Tax rate input
  const taxRateInput = document.getElementById('taxRateInput');
  if (taxRateInput) {
    taxRateInput.addEventListener('input', (e) => {
      billingState.taxRate = parseFloat(e.target.value) || 0;
      billingState.items.forEach(i => i.taxRate = billingState.taxRate);
      recalculateTotals();
    });
  }

  // Paid amount input
  const paidAmountInput = document.getElementById('paidAmountInput');
  if (paidAmountInput) {
    paidAmountInput.addEventListener('input', (e) => {
      billingState.paidAmount = parseFloat(e.target.value) || 0;
      recalculateTotals();
    });
  }

  // Pay Exact Amount button
  const payExactBtn = document.getElementById('payExactBtn');
  if (payExactBtn) {
    payExactBtn.addEventListener('click', () => {
      if (billingState.computed) {
        billingState.paidAmount = billingState.computed.grandTotal;
        paidAmountInput.value = billingState.paidAmount.toFixed(2);
        recalculateTotals();
      }
    });
  }

  // Invoice Date & Number inputs
  const invoiceDateInput = document.getElementById('invoiceDate');
  if (invoiceDateInput) {
    invoiceDateInput.addEventListener('change', (e) => {
      billingState.date = e.target.value;
    });
  }

  // Clear Invoice
  const clearBtn = document.getElementById('clearInvoiceBtn');
  if (clearBtn) {
    clearBtn.addEventListener('click', () => {
      if (billingState.items.length === 0 || confirm('Clear all items from this invoice?')) {
        resetInvoiceForm();
        Utils.showToast('Invoice cleared.', 'info');
      }
    });
  }

  // Save & Print Button
  const saveAndPrintBtn = document.getElementById('saveAndPrintBtn');
  if (saveAndPrintBtn) {
    saveAndPrintBtn.addEventListener('click', async () => {
      const savedInv = await saveInvoiceRecord();
      if (savedInv) {
        ReceiptManager.showPreview(savedInv);
      }
    });
  }

  // Save Only Button
  const saveOnlyBtn = document.getElementById('saveOnlyBtn');
  if (saveOnlyBtn) {
    saveOnlyBtn.addEventListener('click', async () => {
      const savedInv = await saveInvoiceRecord();
      if (savedInv) {
        Utils.showToast(`Invoice #${savedInv.invoiceNumber} saved successfully!`, 'success');
        resetInvoiceForm();
      }
    });
  }

  // Print Preview Button
  const printPreviewBtn = document.getElementById('printPreviewBtn');
  if (printPreviewBtn) {
    printPreviewBtn.addEventListener('click', () => {
      if (billingState.items.length === 0) {
        Utils.showToast('Please add at least one product before previewing receipt.', 'warning');
        return;
      }
      recalculateTotals();
      const mockInv = buildInvoiceObject();
      ReceiptManager.showPreview(mockInv);
    });
  }
}

/**
 * Validates and compiles the invoice object
 */
function buildInvoiceObject() {
  const notes = document.getElementById('invoiceNotes') ? document.getElementById('invoiceNotes').value.trim() : '';

  return {
    id: Utils.generateId('inv'),
    invoiceNumber: billingState.invoiceNumber,
    date: billingState.date,
    time: billingState.time || Utils.getCurrentTimeStr(),
    customerId: billingState.customerId,
    customerSnapshot: { ...billingState.customerSnapshot },
    items: billingState.items.map(item => ({
      productId: item.productId,
      name: item.name,
      sku: item.sku,
      quantity: item.quantity,
      unitPrice: item.unitPrice,
      discount: item.discount,
      taxRate: item.taxRate,
      lineTotal: item.lineTotal
    })),
    subtotal: billingState.computed.subtotal,
    discount: billingState.computed.discount,
    tax: billingState.computed.tax,
    grandTotal: billingState.computed.grandTotal,
    paidAmount: billingState.computed.paidAmount,
    remainingBalance: billingState.computed.remainingBalance,
    changeReturned: billingState.computed.changeReturned,
    paymentMethod: billingState.paymentMethod,
    paymentStatus: billingState.computed.paymentStatus,
    notes: notes,
    createdAt: new Date().toISOString()
  };
}

/**
 * Validates and saves invoice into IndexedDB, updates inventory
 */
async function saveInvoiceRecord() {
  if (billingState.items.length === 0) {
    Utils.showToast('Invoice cannot be saved without at least one product item.', 'error');
    return null;
  }

  // Recalculate totals directly in JS before saving
  recalculateTotals();

  // Validate items
  for (const item of billingState.items) {
    if (!item.name || item.name.trim() === '') {
      Utils.showToast('Every item must have a valid name.', 'error');
      return null;
    }
    if (item.quantity <= 0) {
      Utils.showToast(`Invalid quantity for "${item.name}". Must be greater than 0.`, 'error');
      return null;
    }
    if (item.unitPrice < 0) {
      Utils.showToast(`Invalid price for "${item.name}". Price cannot be negative.`, 'error');
      return null;
    }
  }

  const invoice = buildInvoiceObject();

  try {
    // 1. Save invoice to IndexedDB
    await db.put('invoices', invoice);

    // 2. Deduct inventory if enabled
    if (billingState.inventoryTracking) {
      for (const item of invoice.items) {
        if (item.productId) {
          const prod = await db.getById('products', item.productId);
          if (prod) {
            prod.stockQuantity = Math.max(0, (Number(prod.stockQuantity) || 0) - item.quantity);
            await db.put('products', prod);

            // Log inventory transaction
            await db.put('inventoryTransactions', {
              id: Utils.generateId('tx'),
              productId: item.productId,
              type: 'sale',
              quantity: -item.quantity,
              referenceId: invoice.invoiceNumber,
              createdAt: new Date().toISOString()
            });
          }
        }
      }
      // Refresh cached products
      allProductsCache = await db.getAll('products');
    }

    return invoice;
  } catch (err) {
    console.error('Error saving invoice:', err);
    Utils.showToast('Failed to save invoice to database.', 'error');
    return null;
  }
}

/**
 * Resets the billing form for a new invoice
 */
async function resetInvoiceForm() {
  billingState.items = [];
  billingState.overallDiscount = 0;
  billingState.paidAmount = 0;
  billingState.invoiceNumber = await db.getNextInvoiceNumber();
  billingState.date = Utils.getCurrentDateISO();
  billingState.time = Utils.getCurrentTimeStr();

  const numInput = document.getElementById('invoiceNumber');
  if (numInput) numInput.value = billingState.invoiceNumber;

  const dateInput = document.getElementById('invoiceDate');
  if (dateInput) dateInput.value = billingState.date;

  const paidInput = document.getElementById('paidAmountInput');
  if (paidInput) paidInput.value = '';

  const discInput = document.getElementById('overallDiscountInput');
  if (discInput) discInput.value = '';

  const notesInput = document.getElementById('invoiceNotes');
  if (notesInput) notesInput.value = '';

  handleCustomerChange('walk-in');
  document.getElementById('customerSelect').value = 'walk-in';

  renderItemsTable();
  recalculateTotals();
}

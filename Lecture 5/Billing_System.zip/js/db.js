/**
 * SmartBill - Centralized IndexedDB Storage Layer
 * Database Name: SmartBillDB
 * Object Stores: invoices, products, customers, settings, inventoryTransactions
 */

const DB_NAME = 'SmartBillDB';
const DB_VERSION = 1;

class SmartBillDatabase {
  constructor() {
    this.db = null;
    this.initPromise = null;
  }

  /**
   * Initializes and opens the IndexedDB connection.
   * Returns a Promise resolving to the IDBDatabase instance.
   */
  async initDB() {
    if (this.db) return this.db;
    if (this.initPromise) return this.initPromise;

    this.initPromise = new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = (event) => {
        const db = event.target.result;

        // 1. Invoices Store
        if (!db.objectStoreNames.contains('invoices')) {
          const invoiceStore = db.createObjectStore('invoices', { keyPath: 'id' });
          invoiceStore.createIndex('invoiceNumber', 'invoiceNumber', { unique: true });
          invoiceStore.createIndex('date', 'date', { unique: false });
          invoiceStore.createIndex('customerId', 'customerId', { unique: false });
          invoiceStore.createIndex('paymentStatus', 'paymentStatus', { unique: false });
          invoiceStore.createIndex('createdAt', 'createdAt', { unique: false });
        }

        // 2. Products Store
        if (!db.objectStoreNames.contains('products')) {
          const productStore = db.createObjectStore('products', { keyPath: 'id' });
          productStore.createIndex('sku', 'sku', { unique: true });
          productStore.createIndex('name', 'name', { unique: false });
          productStore.createIndex('category', 'category', { unique: false });
          productStore.createIndex('isActive', 'isActive', { unique: false });
        }

        // 3. Customers Store
        if (!db.objectStoreNames.contains('customers')) {
          const customerStore = db.createObjectStore('customers', { keyPath: 'id' });
          customerStore.createIndex('phone', 'phone', { unique: false });
          customerStore.createIndex('email', 'email', { unique: false });
          customerStore.createIndex('name', 'name', { unique: false });
        }

        // 4. Settings Store
        if (!db.objectStoreNames.contains('settings')) {
          db.createObjectStore('settings', { keyPath: 'key' });
        }

        // 5. Inventory Transactions Store
        if (!db.objectStoreNames.contains('inventoryTransactions')) {
          const invStore = db.createObjectStore('inventoryTransactions', { keyPath: 'id' });
          invStore.createIndex('productId', 'productId', { unique: false });
          invStore.createIndex('type', 'type', { unique: false });
          invStore.createIndex('referenceId', 'referenceId', { unique: false });
          invStore.createIndex('createdAt', 'createdAt', { unique: false });
        }
      };

      request.onsuccess = async (event) => {
        this.db = event.target.result;
        // Initialize default settings if not yet set
        await this.ensureDefaultSettings();
        resolve(this.db);
      };

      request.onerror = (event) => {
        console.error('IndexedDB open error:', event.target.error);
        reject(event.target.error);
      };
    });

    return this.initPromise;
  }

  /**
   * Helper to execute a transaction on a specific store.
   */
  async getTransaction(storeName, mode = 'readonly') {
    const db = await this.initDB();
    return db.transaction(storeName, mode);
  }

  /**
   * Fetch all items from a given store.
   */
  async getAll(storeName) {
    const tx = await this.getTransaction(storeName, 'readonly');
    const store = tx.objectStore(storeName);

    return new Promise((resolve, reject) => {
      const request = store.getAll();
      request.onsuccess = () => resolve(request.result || []);
      request.onerror = () => reject(request.error);
    });
  }

  /**
   * Fetch an item by primary key.
   */
  async getById(storeName, id) {
    const tx = await this.getTransaction(storeName, 'readonly');
    const store = tx.objectStore(storeName);

    return new Promise((resolve, reject) => {
      const request = store.get(id);
      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => reject(request.error);
    });
  }

  /**
   * Fetch items matching an index value.
   */
  async getByIndex(storeName, indexName, value) {
    const tx = await this.getTransaction(storeName, 'readonly');
    const store = tx.objectStore(storeName);
    const index = store.index(indexName);

    return new Promise((resolve, reject) => {
      const request = index.getAll(value);
      request.onsuccess = () => resolve(request.result || []);
      request.onerror = () => reject(request.error);
    });
  }

  /**
   * Add a new item to a store.
   */
  async add(storeName, item) {
    const tx = await this.getTransaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);

    return new Promise((resolve, reject) => {
      const request = store.add(item);
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  /**
   * Update or insert an item.
   */
  async put(storeName, item) {
    const tx = await this.getTransaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);

    return new Promise((resolve, reject) => {
      const request = store.put(item);
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  /**
   * Delete an item by ID.
   */
  async deleteItem(storeName, id) {
    const tx = await this.getTransaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);

    return new Promise((resolve, reject) => {
      const request = store.delete(id);
      request.onsuccess = () => resolve(true);
      request.onerror = () => reject(request.error);
    });
  }

  /**
   * Clear an entire object store.
   */
  async clearStore(storeName) {
    const tx = await this.getTransaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);

    return new Promise((resolve, reject) => {
      const request = store.clear();
      request.onsuccess = () => resolve(true);
      request.onerror = () => reject(request.error);
    });
  }

  /* --------------------------------------------------------------------------
     Settings Specific Helpers
     -------------------------------------------------------------------------- */
  async getSetting(key, defaultValue = null) {
    try {
      const item = await this.getById('settings', key);
      return item ? item.value : defaultValue;
    } catch (e) {
      console.warn('Error reading setting:', key, e);
      return defaultValue;
    }
  }

  async setSetting(key, value) {
    return this.put('settings', { key, value, updatedAt: new Date().toISOString() });
  }

  async getAllSettings() {
    const items = await this.getAll('settings');
    const config = {};
    items.forEach(item => {
      config[item.key] = item.value;
    });
    return config;
  }

  async ensureDefaultSettings() {
    const defaults = {
      businessName: 'Apex Retail Store',
      ownerName: 'Store Manager',
      businessPhone: '+1 (555) 234-5678',
      businessEmail: 'info@apexretail.com',
      businessAddress: '123 Commerce Way, Suite 400, Metro City',
      businessTaxNo: 'TAX-987654321',
      invoiceFooter: 'Thank you for shopping with us! Please keep this receipt for warranty.',
      invoicePrefix: 'INV-',
      startingInvoiceNumber: 1001,
      currencySymbol: '$',
      currencyCode: 'USD',
      decimalPrecision: 2,
      defaultTaxRate: 8.5,
      defaultDiscount: 0,
      defaultPaymentMethod: 'Cash',
      inventoryTracking: true,
      lowStockThreshold: 5,
      businessLogo: '' // Base64 if uploaded
    };

    for (const [key, value] of Object.entries(defaults)) {
      const existing = await this.getById('settings', key);
      if (!existing) {
        await this.put('settings', { key, value, createdAt: new Date().toISOString() });
      }
    }
  }

  /**
   * Calculates the next unique invoice number based on prefix and sequence.
   */
  async getNextInvoiceNumber() {
    const prefix = await this.getSetting('invoicePrefix', 'INV-');
    const startingNumber = parseInt(await this.getSetting('startingInvoiceNumber', 1001), 10);
    const invoices = await this.getAll('invoices');

    if (invoices.length === 0) {
      return `${prefix}${startingNumber.toString().padStart(6, '0')}`;
    }

    // Find the highest sequence number
    let highestSeq = startingNumber - 1;
    for (const inv of invoices) {
      if (inv.invoiceNumber && inv.invoiceNumber.startsWith(prefix)) {
        const numPart = parseInt(inv.invoiceNumber.replace(prefix, ''), 10);
        if (!isNaN(numPart) && numPart > highestSeq) {
          highestSeq = numPart;
        }
      }
    }

    const nextSeq = Math.max(highestSeq + 1, startingNumber);
    return `${prefix}${nextSeq.toString().padStart(6, '0')}`;
  }

  /* --------------------------------------------------------------------------
     Export / Import & Demo Data Helpers
     -------------------------------------------------------------------------- */
  async exportDatabase() {
    const invoices = await this.getAll('invoices');
    const products = await this.getAll('products');
    const customers = await this.getAll('customers');
    const settings = await this.getAll('settings');
    const inventoryTransactions = await this.getAll('inventoryTransactions');

    return {
      version: '1.0',
      exportedAt: new Date().toISOString(),
      appName: 'SmartBill',
      data: {
        invoices,
        products,
        customers,
        settings,
        inventoryTransactions
      }
    };
  }

  async importDatabase(importedObj) {
    if (!importedObj || !importedObj.data) {
      throw new Error('Invalid backup file format.');
    }

    const { invoices, products, customers, settings, inventoryTransactions } = importedObj.data;

    // Clear existing
    await this.clearStore('invoices');
    await this.clearStore('products');
    await this.clearStore('customers');
    await this.clearStore('settings');
    await this.clearStore('inventoryTransactions');

    // Restore stores
    if (Array.isArray(settings)) {
      for (const s of settings) await this.put('settings', s);
    }
    if (Array.isArray(products)) {
      for (const p of products) await this.put('products', p);
    }
    if (Array.isArray(customers)) {
      for (const c of customers) await this.put('customers', c);
    }
    if (Array.isArray(invoices)) {
      for (const i of invoices) await this.put('invoices', i);
    }
    if (Array.isArray(inventoryTransactions)) {
      for (const t of inventoryTransactions) await this.put('inventoryTransactions', t);
    }

    return true;
  }

  /**
   * Inserts realistic demo products, customers, and invoices.
   */
  async seedDemoData() {
    // 1. Realistic Products
    const demoProducts = [
      {
        id: 'prod_001',
        name: 'Wireless Ergonomic Mouse',
        sku: 'ELEC-WEM-01',
        category: 'Electronics',
        description: '2.4GHz rechargeable ergonomic vertical mouse with silent clicks.',
        purchasePrice: 15.00,
        sellingPrice: 29.99,
        stockQuantity: 24,
        lowStockThreshold: 5,
        isActive: true,
        createdAt: new Date(Date.now() - 30 * 86400000).toISOString()
      },
      {
        id: 'prod_002',
        name: 'Mechanical RGB Keyboard',
        sku: 'ELEC-KB-02',
        category: 'Electronics',
        description: 'Tenkeyless mechanical gaming keyboard with hot-swappable switches.',
        purchasePrice: 42.00,
        sellingPrice: 79.50,
        stockQuantity: 12,
        lowStockThreshold: 4,
        isActive: true,
        createdAt: new Date(Date.now() - 25 * 86400000).toISOString()
      },
      {
        id: 'prod_003',
        name: 'Organic Fair-Trade Coffee Beans (1kg)',
        sku: 'GROC-COF-03',
        category: 'Groceries',
        description: 'Medium roast whole bean arabica coffee with chocolate notes.',
        purchasePrice: 11.50,
        sellingPrice: 19.95,
        stockQuantity: 40,
        lowStockThreshold: 10,
        isActive: true,
        createdAt: new Date(Date.now() - 20 * 86400000).toISOString()
      },
      {
        id: 'prod_004',
        name: 'Insulated Stainless Steel Bottle (750ml)',
        sku: 'ACC-BOT-04',
        category: 'Accessories',
        description: 'Double-wall vacuum flask keeps beverages cold for 24 hours.',
        purchasePrice: 8.20,
        sellingPrice: 18.50,
        stockQuantity: 3, // Low stock demo!
        lowStockThreshold: 5,
        isActive: true,
        createdAt: new Date(Date.now() - 15 * 86400000).toISOString()
      },
      {
        id: 'prod_005',
        name: 'USB-C Fast Charging Cable (2m)',
        sku: 'ELEC-CAB-05',
        category: 'Electronics',
        description: '100W braided nylon durable USB-C charging and data cable.',
        purchasePrice: 3.50,
        sellingPrice: 9.99,
        stockQuantity: 50,
        lowStockThreshold: 8,
        isActive: true,
        createdAt: new Date(Date.now() - 10 * 86400000).toISOString()
      },
      {
        id: 'prod_006',
        name: 'Desk Pad Leather Mat (80x40cm)',
        sku: 'OFF-PAD-06',
        category: 'Office',
        description: 'Waterproof PU leather desk blotter and mousepad.',
        purchasePrice: 9.00,
        sellingPrice: 22.00,
        stockQuantity: 2, // Low stock demo!
        lowStockThreshold: 4,
        isActive: true,
        createdAt: new Date(Date.now() - 8 * 86400000).toISOString()
      }
    ];

    for (const p of demoProducts) {
      await this.put('products', p);
    }

    // 2. Realistic Customers
    const demoCustomers = [
      {
        id: 'cust_001',
        name: 'Sarah Jenkins',
        phone: '+1 (555) 432-8901',
        email: 'sarah.jenkins@example.com',
        address: '45 Elm Street, Springfield',
        notes: 'Regular customer, prefers email receipts.',
        createdAt: new Date(Date.now() - 20 * 86400000).toISOString()
      },
      {
        id: 'cust_002',
        name: 'David Martinez',
        phone: '+1 (555) 765-2109',
        email: 'd.martinez@techcorp.io',
        address: '88 Tech Boulevard, Silicon District',
        notes: 'Corporate purchases for local office.',
        createdAt: new Date(Date.now() - 15 * 86400000).toISOString()
      },
      {
        id: 'cust_003',
        name: 'Emily Watson',
        phone: '+1 (555) 908-3344',
        email: 'emily.w@designstudio.org',
        address: '12 Art Studio Lane, Old Town',
        notes: 'Requested wholesale discount in future.',
        createdAt: new Date(Date.now() - 10 * 86400000).toISOString()
      }
    ];

    for (const c of demoCustomers) {
      await this.put('customers', c);
    }

    // 3. Realistic Historical Invoices
    const today = new Date();
    const formatDate = (d) => d.toISOString().split('T')[0];

    const demoInvoices = [
      {
        id: 'inv_001',
        invoiceNumber: 'INV-001001',
        date: formatDate(new Date(Date.now() - 3 * 86400000)),
        time: '11:20 AM',
        customerId: 'cust_001',
        customerSnapshot: {
          name: 'Sarah Jenkins',
          phone: '+1 (555) 432-8901',
          email: 'sarah.jenkins@example.com',
          address: '45 Elm Street, Springfield'
        },
        items: [
          {
            productId: 'prod_001',
            name: 'Wireless Ergonomic Mouse',
            sku: 'ELEC-WEM-01',
            quantity: 1,
            unitPrice: 29.99,
            discount: 0,
            taxRate: 8.5,
            lineTotal: 29.99
          },
          {
            productId: 'prod_005',
            name: 'USB-C Fast Charging Cable (2m)',
            sku: 'ELEC-CAB-05',
            quantity: 2,
            unitPrice: 9.99,
            discount: 0,
            taxRate: 8.5,
            lineTotal: 19.98
          }
        ],
        subtotal: 49.97,
        discount: 0,
        tax: 4.25,
        grandTotal: 54.22,
        paidAmount: 54.22,
        remainingBalance: 0,
        changeReturned: 0,
        paymentMethod: 'Card',
        paymentStatus: 'Paid',
        notes: 'Paid via Visa contactless.',
        createdAt: new Date(Date.now() - 3 * 86400000).toISOString()
      },
      {
        id: 'inv_002',
        invoiceNumber: 'INV-001002',
        date: formatDate(new Date(Date.now() - 1 * 86400000)),
        time: '02:45 PM',
        customerId: 'cust_002',
        customerSnapshot: {
          name: 'David Martinez',
          phone: '+1 (555) 765-2109',
          email: 'd.martinez@techcorp.io',
          address: '88 Tech Boulevard, Silicon District'
        },
        items: [
          {
            productId: 'prod_002',
            name: 'Mechanical RGB Keyboard',
            sku: 'ELEC-KB-02',
            quantity: 2,
            unitPrice: 79.50,
            discount: 10, // $10 coupon discount
            taxRate: 8.5,
            lineTotal: 149.00
          },
          {
            productId: 'prod_006',
            name: 'Desk Pad Leather Mat (80x40cm)',
            sku: 'OFF-PAD-06',
            quantity: 2,
            unitPrice: 22.00,
            discount: 0,
            taxRate: 8.5,
            lineTotal: 44.00
          }
        ],
        subtotal: 193.00,
        discount: 10.00,
        tax: 15.56,
        grandTotal: 198.56,
        paidAmount: 198.56,
        remainingBalance: 0,
        changeReturned: 0,
        paymentMethod: 'Bank Transfer',
        paymentStatus: 'Paid',
        notes: 'Corporate purchase order #PO-409.',
        createdAt: new Date(Date.now() - 1 * 86400000).toISOString()
      },
      {
        id: 'inv_003',
        invoiceNumber: 'INV-001003',
        date: formatDate(today),
        time: '09:15 AM',
        customerId: 'walk-in',
        customerSnapshot: {
          name: 'Walk-in Customer',
          phone: '-',
          email: '-',
          address: '-'
        },
        items: [
          {
            productId: 'prod_003',
            name: 'Organic Fair-Trade Coffee Beans (1kg)',
            sku: 'GROC-COF-03',
            quantity: 2,
            unitPrice: 19.95,
            discount: 0,
            taxRate: 8.5,
            lineTotal: 39.90
          }
        ],
        subtotal: 39.90,
        discount: 0,
        tax: 3.39,
        grandTotal: 43.29,
        paidAmount: 50.00,
        remainingBalance: 0,
        changeReturned: 6.71,
        paymentMethod: 'Cash',
        paymentStatus: 'Paid',
        notes: 'Walk-in retail customer.',
        createdAt: new Date().toISOString()
      }
    ];

    for (const inv of demoInvoices) {
      await this.put('invoices', inv);
    }

    return true;
  }

  /**
   * Resets all stores to clean state.
   */
  async clearAllData() {
    await this.clearStore('invoices');
    await this.clearStore('products');
    await this.clearStore('customers');
    await this.clearStore('inventoryTransactions');
    await this.clearStore('settings');
    await this.ensureDefaultSettings();
    return true;
  }
}

// Export a single instance to be used application-wide
const db = new SmartBillDatabase();
